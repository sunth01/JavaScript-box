<template>
  <div id="app">
    <h1>动态组件dynamic的学习</h1>
    <button class="my-btn-primary" @click="comName = 'UserAccount'">
      账号密码填写
    </button>
    <button class="my-btn-success" @click="comName = 'UserInfo'">
      个人信息填写
    </button>

    <!--
      动态组件的使用 ( component 组件 + is 属性 )
      (1) 设置挂载点<component>, (在哪显示)
      (2) 使用is属性来设置要显示哪个组件 (显示哪一个组件)
    -->
    <!-- 挖个坑，在这个位置切换组件 -->
    <component :is="comName"></component>
  </div>
</template>

<script>
import UserAccount from './components/UserAccount.vue'
import UserInfo from './components/UserInfo.vue'
export default {
  components: {
    UserAccount,
    UserInfo
  },
  data () {
    return {
      comName: 'UserAccount'
    }
  }
}
</script>

<style lang="less">
#app {
  padding: 20px;
  .my-btn-primary {
    margin-right: 10px;
  }
}
</style>
