<template>
  <div>
    <div style="border: 1px solid #ccc; margin: 10px; padding: 10px">
      <h4>商品 - 大衣 - 99 元</h4>
      <!-- 需求：将下面的数字加减框，封装成一个通用的组件 -->
      <number-box></number-box>
    </div>
  </div>
</template>

<script>
import NumberBox from './components/number-box.vue'
export default {
  components: {
    NumberBox
  },
  data () {
    return {
      count: 10 
    }
  }
}
</script>

<style>

</style>