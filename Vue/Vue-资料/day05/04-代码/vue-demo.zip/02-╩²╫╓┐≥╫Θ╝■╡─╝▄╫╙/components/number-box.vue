<template>
  <div>
    <button>-</button>
    <span>1</span>
    <button>+</button>
  </div>
</template>

<script>
export default {
  name: 'NumberBox'
}
</script>

<style lang="less" scoped>
span {
  display: inline-block;
  margin: 0 5px;
}
</style>