<template>
  <div>
    <button @click="sub">-</button>
    <span>{{ value }}</span>
    <button @click="add">+</button>
  </div>
</template>
<script>
export default {
  name: 'NumberBox',
  props: {
    value: Number
  },
  methods: {
    add () {
      // 触发的是自定义事件, 请注意，组件上触发的事件名仅仅只是一个标识，可以任意起
      // 千万不要觉得 click input change 不能起 （错误的！） 
      this.$emit('input', this.value + 1)
    },
    sub () {
      this.$emit('input', this.value - 1)
    }
  }
}
</script>

<style lang="less" scoped>
span {
  display: inline-block;
  margin: 0 5px;
}
</style>