<template>
  <div>
    <h3>下拉菜单的封装 - {{ cityId }}</h3>
    <!-- v-model => :value + @input -->
    <hm-select v-model="cityId"></hm-select>
  </div>
</template>

<script>
import HmSelect from './components/hm-select.vue'
export default {
  data () {
    return {
      cityId: '107'
    }
  },
  components: {
    HmSelect
  }
}
</script>

<style>

</style>