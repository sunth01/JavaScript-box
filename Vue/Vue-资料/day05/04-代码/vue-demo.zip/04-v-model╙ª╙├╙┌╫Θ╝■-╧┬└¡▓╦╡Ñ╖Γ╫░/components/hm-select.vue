<template>
  <div>
    <!-- select框的value值，就是选中的option的value值，既可以用于获取，也可以用于设置 -->
    <select :value="value" @change="handleChange">
      <option value="101">上海</option>
      <option value="103">北京</option>
      <option value="107">广州</option>
      <option value="110">深圳</option>
    </select>
  </div>
</template>

<script>
export default {
  props: {
    value: String
  },
  methods: {
    handleChange (e) {
      // console.log(e.target.value)
      this.$emit('input', e.target.value)
    }
  }
}
</script>

<style>

</style>