<template>
  <div>
    <!-- 一进入页面，就获取焦点 -->
    <!-- <input v-border ref="inp" type="text">
    <textarea v-focus v-border name="" id="" cols="30" rows="10"></textarea>
    <p v-border>123</p> -->

    <hr>

    <h3 v-color="color1">我是标题-红色</h3>
    <p v-color="color2">我是普通文字-蓝色</p>
  </div>
</template>

<script>
export default {

  data () {
    return {
      color1: 'red',
      color2: 'blue'
    }
  },
  // 生命周期函数：人是有生老病死的，vue也一样，从创建到销毁，有着各个的生命周期阶段
  // mounted：这个函数会在组件的模板结构渲染成功之后，执行 （dom准备就绪）
  // mounted() {
  //   // console.log(11111)
  //   this.$refs.inp.focus()
  // }

  directives: {
    // v-for 指令名 for
    // v-focus 指令名 focus，定义指令名，无需加上v-，使用时加上v-即可
    focus: {
      // 当指令所在的元素节点，被插入到页面中触发，dom已经解析完成，可以操作dom
      inserted (el) {
        // el: element 元素 指令所在的元素节点
        // console.log(el)
        el.focus()
      }
    }
  }
}
</script>

<style>

</style>