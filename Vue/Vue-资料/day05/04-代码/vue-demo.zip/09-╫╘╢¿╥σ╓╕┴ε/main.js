import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// Vue.directive(指令名, 指令的配置对象)
Vue.directive('border', {
  // 指令所在的元素，被插入到页面节点中触发，此时可以操作dom
  inserted (el) {
    el.style.border = '1px solid orange'
    el.style.boxShadow = 'orange 1px 1px 1px 1px'
  }
})

// v-color="xxx" 指令的值 => binding.value
Vue.directive('color', {
  // inserted只会在元素被插入到页面中时触发，指令的值修改时，不会触发
  inserted (el, binding) {
    el.style.color = binding.value
  },
  // update: 当指令绑定的值修改时，会触发
  update (el, binding) {
    el.style.color = binding.value
  }
})

new Vue({
  render: h => h(App)
}).$mount('#app')
