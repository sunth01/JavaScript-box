<template>
  <div>
    <input v-if="isSearch" ref="inp" type="text" placeholder="请输入要搜索的关键字">
    <button v-else @click="change">点击搜索</button>
  </div>
</template>

<script>
// dom.focus() 获取焦点
export default {
  data () {
    return {
      isSearch: false
    }
  },
  methods: {
    change () {
      // 将状态，切换成true => 输入框 要 显示了
      this.isSearch = true

      // console.log(this.$refs.inp)
      // this.$refs.inp.focus()
      // 需要等，等输入框完全显示出来了之后，才获取焦点
      this.$nextTick(() => {
        this.$refs.inp.focus()
      })
    }
  }
}
</script>

<style>

</style>