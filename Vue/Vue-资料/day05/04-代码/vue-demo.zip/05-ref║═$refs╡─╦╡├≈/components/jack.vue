<template>
  <div>
    我是jack组件, 我的技能: 跳街舞, 唱rap
    <button @click="sing">唱歌</button>
    <button @click="dance">跳舞</button>
  </div>
</template>

<script>
export default {
  name: 'MyJack',
  data () {
    return {
      age: 18
    }
  },
  methods: {
    dance () {
      console.log('动词打次，跳街舞')
    },
    sing () {
      console.log('2555, 2555 唱歌~')
    }
  }
}
</script>

<style>

</style>