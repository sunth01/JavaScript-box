<template>
  <div id="app">
    <!-- 只需要留一个默认的路由出口 -->
    <!-- <hm-button />   <hm-button></hm-button> -->
    <!-- <router-view /> -->
    <router-view></router-view>
  </div>
</template>

<style lang="less">

</style>
