import Vue from "vue";
import VueRouter from "vue-router";
import Login from '@/views/login'
import Register from '@/views/register'
import Article from '@/views/article'
import List from '@/views/list'
import User from '@/views/user'
import Page404 from '@/views/page404'

Vue.use(VueRouter)

const router = new VueRouter({
  // 前端，history 还是 hash，前端代码不用做任何的修改  =>  后台需要一定的配置
  mode: 'history',
  routes: [
    { path: '/', redirect: '/login' },
    { path: '/login', component: Login },
    { path: '/register', component: Register },
    { path: '/article', component: Article },
    { path: '/list', name: 'list', component: List },

    // 注意：这里在配置动态路由 
    // :id 这个位置表示需要传 id
    { path: '/user/:id', component: User },

    // 注意：404的配置，一定要放最后，表示上面的路径都没有命中时，给个默认展示
    { path: '*', component: Page404 }
  ]
})

export default router