<template>
  <div>
    <!-- 明确：
         1.传统页面，A页面 => B页面，跳转可以传值
         2.单页应用，A页面组件 => B页面组件，跳转也应该可以传值
           B页面组件能够解析参数，实现功能
     -->
    <!-- 导航链接 -->
    <router-link to="/login">登录</router-link>
    <router-link to="/article">文章</router-link>
    
    <router-link to="/register">注册</router-link>
    <router-link to="/list">列表</router-link>
    <hr>
    <!-- 路由出口 -->
    <router-view></router-view>
  </div>
</template>

<style lang="less" scoped>
a {
  display: inline-block;
  margin-right: 10px;
  text-decoration: none;
}
.router-link-active {
  color: red;
}
</style>