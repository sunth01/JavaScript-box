<template>
  <div>
    列表页
    <p>query参数: {{ $route.query }}</p>
    <p>params参数: {{ $route.params }}</p>
  </div>
</template>

<script>
export default {
  name: 'ListIndex'
}
</script>

<style>

</style>