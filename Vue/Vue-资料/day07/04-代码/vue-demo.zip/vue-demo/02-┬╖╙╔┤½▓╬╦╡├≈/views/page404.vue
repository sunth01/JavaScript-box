<template>
  <div>
    <h3>404 NOT FOUND</h3>
  </div>
</template>

<script>
export default {
  name: 'Page404Index'
}
</script>

<style lang="less" scoped>
h3 {
  font-size: 72px;
}
</style>