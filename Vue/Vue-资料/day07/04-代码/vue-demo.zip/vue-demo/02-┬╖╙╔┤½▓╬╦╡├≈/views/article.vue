<template>
  <div>
    文章页
    <p>描述：{{ $route.query.desc || '暂无' }}</p>
    <p>类型：{{ $route.query.type || '暂无' }}</p>
  </div>
</template>

<script>
// router 整个的大的路由实例，唯一
// route  路由规则
// routes 路由规则表（多条路由规则）

// this.$route => 获取当前路由相关的所有信息 （包含路径，参数...）
export default {
  name: 'ArticleIndex',
  created () {
    console.log(this.$route)
    console.log(this.$route.query.desc)
    console.log(this.$route.query.type)
  }
}
</script>

<style>

</style>