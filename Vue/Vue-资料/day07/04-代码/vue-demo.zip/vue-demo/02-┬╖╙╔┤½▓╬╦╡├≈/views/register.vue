<template>
  <div>注册页 - {{ $route.query }}</div>
</template>

<script>
export default {
  name: 'RegisterIndex'
}
</script>

<style>

</style>