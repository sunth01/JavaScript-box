<template>
  <div>
    用户页 - 用户id: {{ $route.params.id }}
  </div>
</template>

<script>
export default {
  name: 'UserIndex'
}
</script>

<style>

</style>