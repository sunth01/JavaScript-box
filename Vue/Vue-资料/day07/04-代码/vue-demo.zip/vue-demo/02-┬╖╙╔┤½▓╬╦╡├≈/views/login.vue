<template>
  <div>
    这是登录页 
    
    <br><br>
    
    <router-link to="/article?desc=武侠&type=长篇小说">
      跳转到文章页-query传值
    </router-link>

    <br><br>

    <router-link to="/user/99">
      跳转到用户页-params-动态路由参数传值
    </router-link>

    <br><hr><br>

    <button @click="goRegister">通过按钮去注册-path</button>
    <button @click="goList">通过按钮去列表-name</button>
  </div>
</template>

<script>
// router 整个的大的路由实例, 唯一的，可以用于路由跳转
// router === this.$router

// route  路由规则相关
// 获取当前路由规则，路径、参数信息等  this.$route
export default {
  name: 'LoginIndex',
  methods: {
    goRegister () {
      // 1. path 不带参数
      // this.$router.push('/register')
      // this.$router.push({
      //   path: '/register'
      // })

      // 2. path 带参数, 需要通过query，会忽略配置的params
      // this.$router.push('/register?username=zs&age=18')
      this.$router.push({
        path: '/register',
        query: {
          username: 'zs',
          age: 18
        }
      })
    },
    goList () {
      // 通过 name 传参，既可以通过query，也可以通过params传参
      // query传参: 拼接在地址栏，刷新不会丢失
      // params传参: 配合name使用，不会显示在地址栏，基于内存，刷新会丢失，使用需要配合本地存储进行持久化
      this.$router.push({
        name: 'list',
        query: {
          username: 'zs',
          age: 18
        },
        params: {
          money: 100,
          house: '大房子'
        }
      })
    }
  }
}
</script>

<style>

</style>