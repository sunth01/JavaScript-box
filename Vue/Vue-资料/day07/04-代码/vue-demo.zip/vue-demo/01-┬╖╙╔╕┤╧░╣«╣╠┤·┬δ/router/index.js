import Vue from "vue";
import VueRouter from "vue-router";
import Login from '@/views/login'
import Register from '@/views/register'
import Article from '@/views/article'
import List from '@/views/list'

Vue.use(VueRouter)

const router = new VueRouter({
  routes: [
    { path: '/login', component: Login },
    { path: '/register', component: Register },
    { path: '/article', component: Article },
    { path: '/list', component: List }
  ]
})

export default router