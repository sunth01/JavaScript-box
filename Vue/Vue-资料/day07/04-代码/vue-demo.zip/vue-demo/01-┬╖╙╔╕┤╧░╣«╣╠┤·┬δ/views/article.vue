<template>
  <div>文章页</div>
</template>

<script>
export default {
  name: 'ArticleIndex'
}
</script>

<style>

</style>