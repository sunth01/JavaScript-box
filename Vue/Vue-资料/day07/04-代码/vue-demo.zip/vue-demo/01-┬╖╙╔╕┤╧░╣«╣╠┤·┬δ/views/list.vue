<template>
  <div>列表页</div>
</template>

<script>
export default {
  name: 'ListIndex'
}
</script>

<style>

</style>