import Vue from 'vue'
import App from '@/App.vue'
import router from '@/router'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  router
}).$mount('#app')

// 路由的使用步骤：(5 + 2)
// 5：下载、引入、使用use、创建路由、挂载
// 2：配置规则、准备出口

// yarn add vue-router@3.5.3

