import Vue from 'vue'
import VueRouter from "vue-router";
import Layout from '@/views/layout'
import Detail from '@/views/article-detail'
import Article from '@/views/article'
import Collect from '@/views/collect'
import Like from '@/views/like'
import User from '@/views/user'
Vue.use(VueRouter)

// 这个demo是用于练习路由
const router = new VueRouter({
  routes: [
    { 
      path: '/', 
      component: Layout,
      redirect: '/article',
      children: [
        { path: '/article', component: Article },
        { path: '/collect', component: Collect },
        { path: '/like', component: Like },
        { path: '/user', component: User }
      ]
    },
    // 动态路由传参  80%的艺术 20%的科学  优雅永不过时
    { path: '/detail', component: Detail }
  ]
})

export default router