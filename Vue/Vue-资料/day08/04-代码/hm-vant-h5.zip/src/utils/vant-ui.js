import Vue from 'vue'
import {
  Button,
  Checkbox,
  Tabbar,
  TabbarItem,
  NavBar,
  Form,
  Field,
  Toast
} from 'vant'

Vue.use(Toast)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(NavBar)
Vue.use(Form)
Vue.use(Field)
