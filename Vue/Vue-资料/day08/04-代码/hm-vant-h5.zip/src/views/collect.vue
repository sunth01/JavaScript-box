<template>
  <div class="collect-page">
    收藏页面
  </div>
</template>

<script>
export default {
  name: 'collect-page',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
.collect-page {
  margin-bottom: 50px;
  margin-top: 44px;
}
</style>
