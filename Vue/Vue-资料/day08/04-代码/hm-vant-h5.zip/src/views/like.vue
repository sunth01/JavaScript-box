<template>
  <div class="like-page">
    喜欢
  </div>
</template>

<script>
export default {
  name: 'like-page',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
.like-page {
  margin-bottom: 50px;
  margin-top: 44px;
}
</style>
