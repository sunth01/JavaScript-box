module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  plugins: [
    ['import', {
      libraryName: 'vant',
      libraryDirectory: 'es',
      // 指定样式路径(不同的组件，按需加载不同的样式)
      style: (name) => `${name}/style/less`
    }, 'vant']
  ]
}
