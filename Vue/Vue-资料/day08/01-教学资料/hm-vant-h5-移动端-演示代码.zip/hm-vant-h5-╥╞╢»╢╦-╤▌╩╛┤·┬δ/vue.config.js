const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  css: {
    loaderOptions: {
      less: {
        // 我们版本 7.2.1+
        // 若 less-loader 版本小于 6.0，请移除 lessOptions 这一级，直接配置选项。
        lessOptions: {
          modifyVars: {
            // 直接覆盖变量
            blue: '#fa6d1d' // 将vant中出现最频繁的蓝色，统一覆盖成橘色（主题色）
          }
        }
      }
    }
  }
})
