import Vue from 'vue'
import App from './App.vue'
import router from './router'
import './utils/vant-ui'
import ArticleItem from '@/components/ArticleItem'
// 这是一个注释
Vue.config.productionTip = false

// 如果一个组件，在很多地方都要用到，可以注册成全局组件 => 只需要注册一次
Vue.component('ArticleItem', ArticleItem)

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
