// import Vant from 'vant'
// import 'vant/lib/index.css'
// // 把vant中所有的组件都导入了
// Vue.use(Vant)
// 1. 全部导入：将vant组件库中的所有组件，全部导入进来，不管用不用到，都导入
//    开发 => 全部导入很方便。     实际上线 => 性能低
// 2. 按需导入：需要用什么组件，加载哪个组件 （合理）
//    开发 => 按需导入比较麻烦。   实际上线 => 性能高
import Vue from 'vue'
import {
  Button,
  Swipe,
  SwipeItem,
  Rate,
  Tabbar,
  TabbarItem,
  Icon,
  NavBar,
  Form,
  Field,
  Toast,
  Cell,
  List,
  Grid,
  GridItem,
  CellGroup
} from 'vant'

Vue.use(Grid)
Vue.use(GridItem)
Vue.use(CellGroup)
Vue.use(Cell)
Vue.use(List)
Vue.use(NavBar)
Vue.use(Form)
Vue.use(Field)
Vue.use(Icon)
Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(Button)
Vue.use(Swipe)
Vue.use(SwipeItem)
Vue.use(Rate)
Vue.use(Toast)
