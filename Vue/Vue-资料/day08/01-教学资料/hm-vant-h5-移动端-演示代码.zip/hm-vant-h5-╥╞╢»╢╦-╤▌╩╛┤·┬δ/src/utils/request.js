/* 封装axios用于发送请求 */
import router from '@/router'
import axios from 'axios'
import { Toast } from 'vant'
import { delToken, getToken } from './storage'

// 创建一个新的axios实例(克隆了一个新的axios，可以后面对这个新实例任意配置)
const request = axios.create({
  baseURL: 'http://interview-api-t.itheima.net/h5/', // 基地址
  timeout: 5000 // 请求超时时间
})

// 添加请求拦截器
request.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  // 如果有token，就需要在每次请求时携带，便于后台识别身份
  const token = getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
}, function (error) {
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 添加响应拦截器
request.interceptors.response.use(function (response) {
  // 成功的情况，已经处理完毕，省略一层默认的 axios 的 .data
  // 对响应数据做点什么
  return response.data
}, function (error) {
  // 后台响应了错误, 统一处理所有的后台给的提示
  if (error.response) {
    // 如果是401，单独提示，直接拦截到登录
    if (error.response.status === 401) {
      // 删除token
      delToken()
      // 给个提示
      Toast('登录已过期，重新登录!')
      // 跳转到登陆页
      // 组件中获取路由对象：this.$router
      // js文件中获取路由对象：router （导入）
      router.push('/login')
    } else {
      Toast(error.response.data.message)
    }
  }
  return Promise.reject(error)
})

export default request

// axios.get
// axios.post

// request.get
// request.post
