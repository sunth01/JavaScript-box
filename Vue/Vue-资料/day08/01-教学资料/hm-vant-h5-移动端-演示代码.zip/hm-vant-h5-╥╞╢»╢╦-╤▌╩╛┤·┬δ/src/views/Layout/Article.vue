<template>
  <div class="article-page">
    <!-- 导航 -->
    <nav class="my-nav van-hairline--bottom">
      <!-- 'weight_desc' 表示 推荐 -->
      <a
        @click="changeSorter('weight_desc')"
        :class="{ active: sorter === 'weight_desc'}"
        href="javascript:;"
        >推荐</a
      >
      <!-- null 表示 最新 -->
      <a
        @click="changeSorter(null)"
        :class="{ active: sorter === null}"
        href="javascript:;"
        >最新</a
      >
      <div class="logo"><img src="@/assets/logo.png" alt=""></div>
    </nav>
    <!--
      1. List 组件通过 loading 和 finished 两个变量控制加载状态，
      2. （页面无数据或）当组件滚动到底部时，会触发 load 事件并将 loading 设置成 true。
      3. 此时可以发起异步操作并更新数据，数据更新完毕后，将 loading 设置成 false 即可。
      4. 若数据已全部加载完毕，则直接将 finished 设置成 true 即可。

      loading是否加载中
      finished是否数据全部加载完毕
      load事件，一旦触底自动触发load事件，执行onLoad方法
    -->
    <van-list
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
    >
      <ArticleItem v-for="item in list" :key="item.id" :item="item"></ArticleItem>
    </van-list>
  </div>
</template>

<script>
import { getArticles } from '@/api/article'
export default {
  name: 'article-page',
  data () {
    return {
      list: [],
      current: 37,
      sorter: 'weight_desc', // 固定的 => 加载推荐数据
      loading: false, // 目前不在加载中，可以触发加载更多
      finished: false // 还有数据
    }
  },
  async created () {

  },
  methods: {
    // 页面一打开，此时无数据，就会触发 onLoad
    // onLoad触发时机(会多次执行)：
    // 1. 一进入页面触发，没数据 => 加载数据
    // 2. 用户往下滑动，即将触底，没数据看了 => 加载更多
    async onLoad () {
      const res = await getArticles({
        current: this.current,
        sorter: this.sorter
      })
      console.log(res)
      // 将请求回来的结果覆盖给了list
      // this.list = res.data.rows // 错误写法，这是覆盖
      this.list.push(...res.data.rows)
      // 加载成功，将loading恢复成false，表示加载完了 => 后面可以加载下一次了
      this.loading = false
      // 加载完成，需要让current++，下一次加载时，加载下一页的数据
      this.current++

      // 做一个加载完成数据的处理 下一页页码 > 总页码 表示数据加载完了
      if (this.current > res.data.pageTotal) {
        this.finished = true // 后续load就不会再次触发了
      }
    },

    changeSorter (sorter) {
      // 更新排序规则，切换了排序规则，一切信息数据要重置
      this.sorter = sorter
      this.list = []
      this.current = 1
      this.finished = false

      // 手动的清空数据，他不知道，我通知他更新一下
      this.onLoad()
      this.loading = true
    }
  }
}
</script>

<style lang="less" scoped>
.article-page {
  margin-bottom: 50px;
  margin-top: 44px;
  .my-nav {
    height: 44px;
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    z-index: 999;
    background: #fff;
    display: flex;
    align-items: center;
    > a {
      color: #999;
      font-size: 14px;
      line-height: 44px;
      margin-left: 20px;
      position: relative;
      transition: all 0.3s;
      &::after {
        content: '';
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        bottom: 0;
        width: 0;
        height: 2px;
        background: #222;
        transition: all 0.3s;
      }
      &.active {
        color: #222;
        &::after {
          width: 14px;
        }
      }
    }
    .logo {
      flex: 1;
      display: flex;
      justify-content: flex-end;
      > img {
        width: 64px;
        height: 28px;
        display: block;
        margin-right: 10px;
      }
    }
  }
}
</style>
