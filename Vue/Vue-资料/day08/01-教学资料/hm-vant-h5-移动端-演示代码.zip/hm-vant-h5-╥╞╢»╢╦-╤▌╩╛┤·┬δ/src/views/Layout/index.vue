<template>
  <div class="layout-page">
    <!-- 二级路由的出口 -->
    <router-view></router-view>

    <van-tabbar route>
      <van-tabbar-item to="/article" icon="notes-o">面经</van-tabbar-item>
      <van-tabbar-item to="/collect" icon="star-o">收藏</van-tabbar-item>
      <van-tabbar-item to="/like" icon="like-o">喜欢</van-tabbar-item>
      <van-tabbar-item to="/user" icon="user-o">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  name: 'layout-page'
}
</script>

<style lang="less" scoped>
// 首先一个个样式覆盖，或者通过官方提供的组件属性，是可以修改组件样式！但是需要一个个改
// .van-tabbar-item--active {
//   // color: #fa6d1d!important;
// }

// 目前：通过主题色，变量覆盖的方式，快速修正整个网站的所有颜色（效率高！）
</style>
