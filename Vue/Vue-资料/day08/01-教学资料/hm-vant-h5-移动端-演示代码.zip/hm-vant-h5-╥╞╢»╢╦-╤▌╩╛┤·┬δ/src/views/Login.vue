<template>
  <div class="login-page">
    <van-nav-bar title="面经登录" />

    <!-- form表单 -->
    <van-form @submit="onSubmit">
      <!-- input 输入框控件 v-model双向绑定 -->
      <van-field
        v-model="username"
        name="username"
        label="用户名"
        placeholder="用户名"
        :rules="[{ required: true, message: '请填写用户名' }]"
      />
      <van-field
        v-model="password"
        type="password"
        name="password"
        label="密码"
        placeholder="密码"
        :rules="[{ required: true, message: '请填写密码' }]"
      />
      <div style="margin: 16px">
        <van-button block type="info" native-type="submit"
          >提交</van-button
        >
      </div>
      <router-link class="link" to="/register">注册账号</router-link>
    </van-form>
  </div>
</template>

<script>
import { login } from '@/api/user'
import { setToken } from '@/utils/storage'
import { Toast } from 'vant'
// 每次如果都需要导包使用，有点麻烦 （目前还好，会自动导入）
// import { Toast } from 'vant'
export default {
  name: 'login-page',
  data () {
    return {
      username: 'shuaipeng',
      password: '123456'
    }
  },
  methods: {
    async onSubmit (values) {
      const res = await login(values)
      // 将token存到本地
      setToken(res.data.token)
      Toast('登录成功')
      this.$router.push('/')
    }

    // onSubmit (values) {
    //   console.log('submit', values)

    //   // 直接调用Toast函数
    //   // 1. Toast('提示内容')  用的最多
    //   // 2. Toast.loading({
    //   //      message: '加载中...',
    //   //      forbidClick: true,
    //   //      duration: 0
    //   //    })

    //   // 3. Toast.clear() 清除提示
    //   // setTimeout(() => {
    //   //   请求成功之后关闭
    //   //   Toast.clear()
    //   // }, 2000)

    //   // 4. Toast.success('成功')

    //   // 借助vue实例，调用Toast函数。当注册Toast组件时，将Toast方法挂载到 vue原型上
    //   // 为了和普通方法区分，起名字 $toast， 作用和 Toast 函数一模一样
    //   this.$toast('hello')
    // }
  }
}
</script>

<style lang="less" scoped>
.link {
  color: #069;
  font-size: 12px;
  padding-right: 20px;
  float: right;
}
</style>
