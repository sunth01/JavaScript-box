import request from '@/utils/request'

// 提供了一个请求参数的接口
// 此处 obj 可以解构
export const getArticles = (obj) => {
  return request.get('/interview/query', {
    params: {
      current: obj.current, // 获取第几页的数据
      sorter: obj.sorter,
      pageSize: 10
    }
  })
}

// 获取我的收藏
export const getArticlesCollect = ({ page }) => {
  // 获取第几页的数据
  return request.get('/interview/opt/list', {
    params: {
      page,
      optType: 2
    }
  })
}

export const getArticlesLike = ({ page }) => {
  return request.get('/interview/opt/list', {
    params: {
      page,
      optType: 1
    }
  })
}

export const getArticleDetail = (id) => {
  return request.get('interview/show', {
    params: {
      id
    }
  })
}

export const updateLike = (id) => {
  return request.post('interview/opt', {
    id,
    optType: 1 // 喜欢
  })
}

export const updateCollect = (id) => {
  return request.post('interview/opt', {
    id,
    optType: 2 // 收藏
  })
}
