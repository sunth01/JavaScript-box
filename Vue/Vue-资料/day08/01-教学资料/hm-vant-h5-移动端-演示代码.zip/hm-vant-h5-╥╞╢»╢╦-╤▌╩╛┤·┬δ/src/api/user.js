import request from '@/utils/request'

// 注册接口封装
export const register = (values) => {
  return request.post('/user/register', values)
}

// 登录接口封装
export const login = (values) => {
  return request.post('/user/login', values)
}

// 获取用户信息
export const getUserInfo = () => {
  return request('/user/currentUser')
}
