import Vue from 'vue'
import VueRouter from 'vue-router'
import Detail from '@/views/Detail'
import Layout from '@/views/Layout/index.vue'
import Login from '@/views/Login'
import Register from '@/views/Register'

import Article from '@/views/Layout/Article'
import Collect from '@/views/Layout/Collect'
import Like from '@/views/Layout/Like'
import User from '@/views/Layout/User'
import { getToken } from '@/utils/storage'

Vue.use(VueRouter)

// 全局前置守卫：
// 1. 所有的路由一旦被匹配到，在真正渲染解析之前，都会先经过全局前置守卫
// 2. 只有全局前置守卫放行，才能看到真正的页面

// 任何路由，被解析访问前，都会先执行这个回调
// 1. from 你从哪里来
// 2. to   你往哪里去
// 3. next() 是否放行，如果next()调用，就是放行 => 放你去想去的页面
//    next(路径) 拦截到某个路径页面

const whiteList = ['/login', '/register']

const router = new VueRouter({
  routes: [
    // 文章的详情，必须要有id才知道，是哪一个文章
    // this.$route.params.id 获取参数
    { path: '/article/:id', component: Detail },
    { path: '/login', component: Login },
    { path: '/register', component: Register },
    {
      path: '/',
      component: Layout,
      children: [
        { path: '/', redirect: '/article' },
        { path: '/article', component: Article },
        { path: '/collect', component: Collect },
        { path: '/like', component: Like },
        { path: '/user', component: User }
      ]
    }
  ]
})

router.beforeEach((to, from, next) => {
  const token = getToken()
  // 如果有token，直接放行
  if (token) {
    next()
  } else {
    // 没有token的人, 看看你要去哪
    // (1) 访问的是无需授权的页面（白名单），也是放行
    //     就是判断，访问的地址，是否在白名单数组中存在 includes
    if (whiteList.includes(to.path)) {
      next()
    } else {
      // (2) 否则拦截到登录
      next('/login')
    }
  }
})

export default router
