<template>
  <div id="app">
    <!-- 从375屏幕中，展示200*200的盒子 -->
    <!-- <div class="box" @click="test"></div> -->
    <!-- 路由出口 -->
    <router-view />
  </div>
</template>

<script>
// import request from '@/utils/request'
// import { getToken, setToken } from '@/utils/storage'
export default {
  data () {
    return {

    }
  },
  methods: {
    async test () {
      // 发送请求测试 - 注册
      // const res = await request.post('/user/register', {
      //   username: 'dashuaipeng',
      //   password: '123456'
      // })
      // console.log(res)

      // 登录
      // const res = await request.post('/user/login', {
      //   username: 'dashuaipeng',
      //   password: '123456'
      // })
      // setToken(res.data.token)

      // // 有了ts的vscode，代码识别提示，自动导入，都会特别稳定（vue3）
      // // 目前：如果能自动导入，就直接自动导入，没有提示，就需要手动出入
      // console.log(getToken())
    }
  }
}
</script>

<style lang="less" scoped>
.box {
  // 写的px，会自动被webpack插件，转vw
  // width: 200px;
  // height: 200px;
  // background-color: pink;
}
</style>
