// postcss.config.js
module.exports = {
  plugins: {
    'postcss-px-to-viewport': {
      // 一般ui给的是2倍图 => 750 / 2   375
      // 如果ui给的是3倍图 => 1080 / 3  360

      // 375 适配的标准屏幕宽度
      viewportWidth: 375
    }
  }
}
