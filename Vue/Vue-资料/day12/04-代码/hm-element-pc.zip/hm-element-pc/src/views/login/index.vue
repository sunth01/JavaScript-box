<template>
  <div class="login-page">
    <!-- 人家组件内部, 必然写了这个 <slot name="header"></slot> -->

    <el-card class="my-card">
      <!-- header插槽 -->
      <template #header>
        <div>黑马面经运营后台</div>
      </template>
      <!-- 默认插槽 -->
      <!--
           实现表单校验：4个关键属性
           el-form 整个form组件
              :model 需要绑定一个对象，对象有着很多属性，每个属性都会和表单元素双向绑定。明确要校验的是哪个对象
              :rules 配置校验的规则

           el-form-item 表单域, 一行, 可以存放格式类型的表单元素
              prop   配置字段名, 决定了校验效果的配置，必须对应 （特别容易漏！！！）

           el-input 文本框
              v-model 和对象中的属性双向绑定，实时收集表单数据
      -->
      <el-form ref="myForm" :model="form" :rules="rules">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input type="password" v-model="form.password" placeholder="请输入密码"></el-input>
        </el-form-item>

        <el-form-item class="tc">
          <el-button type="primary" @click="clickLogin">登录</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
// 原则：每次写导入的时候思考一下，要导入的是按需（多个导出） 还是 默认（单个导出）
import { login } from '@/api/user.js'

export default {
  name: 'LoginIndex',
  data () {
    return {
      form: {
        username: 'admin8',
        password: 'admin'
      },
      rules: {
        // 设置对应字段的校验规则
        // 1. required: true 必填
        // 2. message: xx    错误提示消息
        // 3. trigger: 'blur' / 'change' 设置触发校验的时机，可选项就两个值
        //    (1) blur 失去焦点校验 （常规）
        //    (2) change 实时校验, 类似于输入框input事件的效果
        username: [
          { required: true, message: '请输入账户名称', trigger: ['change', 'blur'] },
          { min: 5, max: 11, message: '长度必须是5-11位', trigger: ['change', 'blur'] }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: ['change', 'blur'] },
          // \d 0-9
          // \w 数字字母下滑线
          // {m,n} 前一个字符可以出现 m ~ n 次 （包含m n）
          { pattern: /^\w{5,11}$/, message: '请输入5-11位的字符', trigger: ['change', 'blur'] }
        ]
      }
    }
  },
  methods: {
    async clickLogin () {
      // 先校验整个表单，通过了校验，才发请求
      // console.log('发请求')
      try {
        // validate 方法会得到一个 promise 对象，前面可以 await 处理
        await this.$refs.myForm.validate()
        // 调用api的login方法，发送请求
        const res = await login(this.form)
        // 公司里面实际规范：将token等个人信息，存入vuex，便于各个页面组件访问 => 存storage（持久化存储）
        // vuex中的数据，类似于data中的数据, 一旦刷新页面，就会重新初始化（vuex刷新会丢失数据）
        // 所有访问token，访问个人信息，一律找vuex。存本地就一个目的：保证刷新之后，vuex的数据还在
        // console.log(res.data.token)
        this.$store.commit('user/setUserToken', res.data.token)

        // 注意：一定要等vuex token存好了，再跳首页
        this.$router.push('/')
      } catch (e) {
        console.log(e)
      }
    },
    reset () {
      // 重置表单，包含 表单内容 + 校验状态的重置 => 调用form的方法
      this.$refs.myForm.resetFields()
    }
  }
}
</script>

<style lang="scss" scoped>
.login-page {
  min-height: 100vh;
  background: url(@/assets/login-bg.svg) no-repeat center / cover;
  // 利用flex水平垂直居中
  display: flex;
  justify-content: center;
  align-items: center;
  .el-card {
    width: 420px;
    ::v-deep .el-card__header{
      height: 80px;
      background: rgba(114,124,245,1);
      text-align: center;
      line-height: 40px;
      color: #fff;
      font-size: 18px;
    }
  }
  .el-form {
    padding: 0 20px;
  }
  .tc {
    text-align: center;
  }
}
// scoped会给下面的所有的类, 新增属性选择器, 可以增加一定的权重
// 如何给组件标签, 设置样式?
// 1. 给组件标签, 加<自定义类>
//    添加的类, 会自动加上渲染出来的组件的根元素上
// .my-card {
//   width: 420px;
//   margin: 0 auto;
// }

// 2. 直接使用<组件标签名>, 作为<类名>控制样式
//    组件库定义组件的规范: 声明的所有组件的根元素, 都有一个和组件名同名的类名(提供给你了)

// 加上scoped, 可以让样式, 只作用于当前组件模板(局部样式)
// 默认scoped样式, 不会向下渗透, 影响到其他子组件的(除了根元素)
// 如果希望样式, 可以向下渗透, 影响到下面的子孙后代, 就需要用到深度作用选择器(vue提供)

// 深度作用选择器:
// ::v-deep   scss
// /deep/     less
// .el-card {
//   width: 420px;
//   margin: 0 auto;
//   // 原理: 一旦选择器前面有深度作用标识, 就会不会附加属性选择器的限制
//   ::v-deep .el-card__header {
//     background-color: #727cf5;
//     text-align: center;
//     color: #fff;
//   }
// }

</style>
