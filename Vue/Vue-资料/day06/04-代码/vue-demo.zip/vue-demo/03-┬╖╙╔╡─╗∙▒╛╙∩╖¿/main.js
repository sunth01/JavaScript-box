// node_modules中三方包，直接写包名导入
import Vue from 'vue'
import VueRouter from 'vue-router'
import Find from './views/find'
import My from './views/my'
import Part from './views/part'

// 自定义模块（自己新建的文件），通过相对路径导入
import App from './App.vue'

// Vue.use是vue内置的插件使用语法
// Vue.use可以进行插件的内部初始化（初始化注册组件、指令...）
Vue.use(VueRouter)  // 一般都是vue相关的插件，才需要use一下

// 创建路由对象
// router: 整个全局最大的路由实例，唯一

// routes: 路由规则列表, 一个数组, 有多条路由规则
//         [{},  {},  {}]
// route:  一条路由规则, 每条路由规则, 都是一个对象, 记录了路径和组件的对应关系
//         { path: 路径,  component: 组件  }

const router = new VueRouter({
  routes: [
    // 这个路径是地址栏的路径
    { path: '/find', component: Find },
    { path: '/my', component: My },
    { path: '/part', component: Part }
  ]
})

Vue.config.productionTip = false

// 构建根实例的（能看到）
new Vue({
  render: h => h(App),
  router
}).$mount('#app')

// 路由的使用步骤 5个基础步骤
// 1. 下载 3.5.3
// 2. 引入 VueRouter
// 3. 使用 Vue.use
// 4. 创建路由
// 5. 挂载注入到 Vue实例

// 2个核心步骤
// 1. 配置路由规则：路径 和 组件的对应 => 告诉你什么路径，应该解析渲染什么组件
// 2. 指定路由出口：router-view 挖个坑 => 决定了匹配的组件，在哪里渲染
