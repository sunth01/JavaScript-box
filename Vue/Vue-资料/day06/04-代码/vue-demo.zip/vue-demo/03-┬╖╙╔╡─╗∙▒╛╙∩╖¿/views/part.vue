<template>
  <div>
    <p>好朋友</p>
    <p>好朋友</p>
    <p>好朋友</p>
  </div>
</template>

<script>
export default {
  name: 'PartIndex'
}
</script>

<style>

</style>