import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// 往原型上加了一个方法，将来所有的组件实例，自己没有，去原型上找，就会找到这个sayHi
Vue.prototype.sayHi = function() {
  console.log('你好哇~')
}

// 构建根实例的（能看到）
new Vue({
  render: h => h(App)
}).$mount('#app')
