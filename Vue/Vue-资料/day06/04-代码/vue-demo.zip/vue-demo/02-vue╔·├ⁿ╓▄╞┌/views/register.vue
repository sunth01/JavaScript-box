<template>
  <div>注册页</div>
</template>

<script>
export default {
  name: 'RegisterIndex'
}
</script>

<style>

</style>