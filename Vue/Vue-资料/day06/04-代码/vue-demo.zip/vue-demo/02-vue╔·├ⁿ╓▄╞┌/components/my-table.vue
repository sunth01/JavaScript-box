<template>
  <!-- 
    表格封装问题：
    1. 数据写死了，希望往组件内部传入表格数据，传数据？父传子
    2. 结构写死了，希望往组件内部传入表格结构，th/td，传结构？插槽

    步骤：
    1. 先准备两个插槽，头部，主体，写了两个具名插槽
    2. 使用的时候，发现主体部分，有数据要用(item index)
    3. 利用作用域插槽，将item index提供在插槽上，供使用组件时渲染
    4. 补上my-tag标签
  -->
  <table class="my-table" ref="table">
    <thead>
      <tr>
        <slot name="head"></slot>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(item, index) in data" :key="item.id">
        <!-- 给你一行的数据, 给你下标 -->
        <slot name="row" :item="item" :index="index"></slot>
      </tr>
    </tbody>
  </table>
</template>

<script>
export default {
  props: {
    // data: Array
    data: {
      type: Array,
      default: () => []
    }
  },
  beforeCreate() {
    // data数据还没有初始化完成, 此时vue实例上还没有绑定数据
    console.log('beforeCreate', this.msg)
  },
  // 至少从created开始，才能操作this.xxx数据 => 发请求获取新数据修改默认数据至少要等到created
  created () {
    // data数据初始化完成, 此时vue实例上绑定好数据了
    console.log('created', this.msg)
    this.msg = '后台的数据'

    this.timeId = setInterval(() => {
      console.log('嘎嘎噶，我是卖报小行家~')
    }, 1000)
  },
  beforeMount() {
    // beforeMount：页面结构还没有解析渲染完成，此时无法获取到dom
    console.log('beforeMount', this.$refs.table)
  },
  mounted() {
    // mounted: 页面结构已经解析渲染完成，此时可以获取到dom
    console.log('mounted', this.$refs.table)
  },
  beforeUpdate() {
    console.log('beforeUpdate', 'dom更新前')
  },
  updated () {
    console.log('beforeUpdate', 'dom更新后')
  },
  beforeDestroy() {
    console.log('beforeDestroy', '实例销毁，资源释放前')
  },
  destroyed () {
    console.log('destroyed', '实例销毁，资源释放后')
    clearInterval(this.timeId)
  },
  data () {
    return {
      msg: 'zs'
    }
  }
}
</script>

<style lang="less" scoped>
.my-table {
  width: 100%;
  border-spacing: 0;
  img {
    width: 100px;
    height: 100px;
    object-fit: contain;
    vertical-align: middle;
  }
  th {
    background: #f5f5f5;
    border-bottom: 2px solid #069;
  }
  td {
    border-bottom: 1px dashed #ccc;
  }
  td,
  th {
    text-align: center;
    padding: 10px;
    transition: all .5s;
    &.red {
      color: red;
    }
  }
  .none {
    height: 100px;
    line-height: 100px;
    color: #999;
  }
}
</style>
