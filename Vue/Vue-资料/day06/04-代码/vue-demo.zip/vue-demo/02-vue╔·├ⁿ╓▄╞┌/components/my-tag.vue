<template>
  <div class="my-tag" @dblclick="open">
    <input
      v-if="edit"
      class="input"
      type="text"
      placeholder="输入标签"
      ref="inp"
      v-focus
      v-model="tag"
      @blur="close"
      @keyup.enter="handleEnter"
    />
    <div v-else class="text">{{ value }}</div>
  </div>
</template>

<script>
// 核心需求：
// 1. 双击@dblclick显示输入框，自动获取焦点 (ref + 自定义指令)
// 2. 失去焦点@blur，隐藏输入框
// 3. 显示时要回显 （明确两份数据）
// 4. 修改标签信息，回车,   显示修改后的标签文本
//    老父亲有份数据 => 通过v-model给子组件进行关联  :value @input
//    儿子自己有份数据 => 自己的数据和输入框绑定关联，显示时，进行同步，回车时，进行同步$emit
export default {
  props: {
    value: String
  },
  data () {
    return {
      edit: false,
      tag: ''
    }
  },
  methods: {
    open () {
      this.edit = true // 让输入框显示（vue是异步dom更新）
      this.tag = this.value // 回显
      this.sayHi()
      // this.$nextTick(() => {
      //   this.$refs.inp.focus()
      // })
    },
    close () {
      this.edit = false
    },
    handleEnter () {
      if (this.tag.trim() === '') return
      this.$emit('input', this.tag)
      this.edit = false
    }
  },
  directives: {
    focus: {
      // 元素被插入到dom节点时触发
      inserted (el) {
        el.focus()
      }
    }
  }
}
</script>

<style lang="less" scoped>
.my-tag {
  cursor: pointer;
  .input {
    appearance: none;
    outline: none;
    border: 1px solid #ccc;
    width: 100px;
    height: 40px;
    box-sizing: border-box;
    padding: 10px;
    color: #666;
    &::placeholder {
      color: #666;
    }
  }
}
</style>