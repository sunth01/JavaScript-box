import Vue from 'vue'
import VueRouter from 'vue-router'

// @ 指代 src 目录，可以直接从 src 出发，找文件 
// 可维护性高！！
import Find from '@/views/find'
import My from '@/views/my'
import Part from '@/views/part'

// Vue.use是vue内置的插件使用语法
// Vue.use可以进行插件的内部初始化（初始化注册组件、指令...）
Vue.use(VueRouter) 

const router = new VueRouter({
  routes: [
    // 这个路径是地址栏的路径
    { path: '/find', component: Find },
    { path: '/my', component: My },
    { path: '/part', component: Part }
  ],
  // 自定义高亮的类名
  linkActiveClass: 'active',  // 配置模糊匹配的类名
  linkExactActiveClass: 'exact' // 配置精确匹配的类名
})

export default router
