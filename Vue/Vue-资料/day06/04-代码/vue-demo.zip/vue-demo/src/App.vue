<template>
  <div>
    <div class="footer_wrap">
      <!-- router-link本质还是a标签，通过 to 配置属性指定跳转路径，to无需# -->
      <!-- 自带高亮的两个类名 -->
      <router-link to="/find">发现音乐</router-link>
      <router-link to="/my">我的音乐</router-link>
      <router-link to="/part">朋友</router-link>

      <!-- router-link-active 模糊 -->
      <!-- router-link-exact-active 精确 -->
    </div>
    <div class="top">
      <!-- 指定出口：决定匹配的组件，在哪渲染 -->
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.footer_wrap {
  position: fixed;
  left: 0;
  top: 0;
  display: flex;
  width: 100%;
  text-align: center;
  background-color: #333;
  color: #ccc;
}
.footer_wrap a {
  flex: 1;
  text-decoration: none;
  padding: 20px 0;
  line-height: 20px;
  background-color: #333;
  color: #ccc;
  border: 1px solid black;
}
.footer_wrap a:hover {
  background-color: #555;
}
.top {
  padding-top: 62px;
}

.active {
  background-color: olive!important;
  color: #fff!important;
}


/* 模糊匹配： to="/my" 可以匹配 /my  /my/aa /my/bb  ...   /my开头 
   匹配上就会给 router-link 的 a 标签，加上类
*/
/* .router-link-active {
  background-color: purple!important;
  color: #fff!important;
} */

/* 精确匹配：to="/my" 可以匹配 /my */
/* .router-link-exact-active {
  background-color: #000!important;
  color: #fff!important;
} */
</style>