// node_modules中三方包，直接写包名导入
import Vue from 'vue'
// 自定义模块（自己新建的文件），通过相对路径导入
import App from '@/App.vue'

// 如果导入的是目录中的index.js 或 index.vue, 
// 可以直接只写目录名，index 可以省略
// './router'  ===  './router/index.js'
import router from '@/router'

Vue.config.productionTip = false

// 构建根实例的（能看到）
new Vue({
  render: h => h(App),
  router
}).$mount('#app')

