<template>
  <div>
    <input type="text" v-model="name1"> +
    <input type="text" v-model="name2"> =
    <span>{{ fullName }}</span>
    <button @click="changeName">改名</button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      name1: '欧阳',
      name2: '霸天'
    }
  },
  methods: {
    changeName() {
      this.fullName = '慕容-云天'
    }
  },
  computed: {
    // 默认只配置了获取
    // fullName () {
    //   return this.name1 + '-' + this.name2
    // }

    // 既要获取又要设置，需要写完整写法
    fullName: {
      get () {
        return this.name1 + '-' + this.name2
      },
      // 就算是设置了计算属性，也不是直接改成功
      // 要基于修改的值，更新依赖项，依赖项更新，计算属性，自然而然就会更新
      set (value) {
        this.name1 = value.split('-')[0]
        this.name2 = value.split('-')[1]
      }
    }
  }
}
</script>

<style>

</style>