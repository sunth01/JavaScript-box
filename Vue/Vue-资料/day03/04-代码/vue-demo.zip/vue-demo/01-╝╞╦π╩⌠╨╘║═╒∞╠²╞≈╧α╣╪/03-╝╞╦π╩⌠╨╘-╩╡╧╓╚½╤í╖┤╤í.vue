<template>
  <div>
    <span>全选:</span>
    <input type="checkbox" v-model="isAll" />

    <!-- 点击反选，forEach，让所有的 item.c 状态取反 -->
    <button >反选</button>
    
    <ul>
      <li v-for="item in arr" :key="item.name">
        <input type="checkbox" v-model="item.c"/>
        <span>{{ item.name }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      arr: [
        {
          name: "猪八戒",
          c: false,
        },
        {
          name: "孙悟空",
          c: true,
        },
        {
          name: "唐僧",
          c: false,
        },
        {
          name: "白龙马",
          c: false,
        },
      ],
    };
  },
  // 计算属性使用场景：
  // 1. 求和，求总价 计算求值...
  // 2. 全选反选 ...
  computed: {
    isAll: {
      get () {
        // every 必须每一个小选框，都选中，isAll才为true
        return this.arr.every(item => item.c === true)
      },
      set (value) {
        // value就是设置的全选框的新状态，需要让所有的小选框同步
        this.arr.forEach(item => item.c = value)
      }
    }
  }
};
</script>

<style>
</style>