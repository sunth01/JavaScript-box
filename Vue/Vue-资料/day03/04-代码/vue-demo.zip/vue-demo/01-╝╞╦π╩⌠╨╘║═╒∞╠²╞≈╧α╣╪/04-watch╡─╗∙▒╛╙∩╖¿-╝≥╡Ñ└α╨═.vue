<template>
  <div>
    <h3>银行卡余额：{{ money }}</h3>
    <button @click="money = money + 20000">发工资</button>
    <button @click="money = money - 15">干饭</button>
    <hr>
    <div>{{ obj }}</div>
    <button @click="obj.age++">过了一年</button>
  </div>
</template>

<script>
export default {
  // 组件的配置项中，除了data是函数，其他一律是对象
  data () {
    return {
      // 需求：只要我卡的钱，变化了，你就发个短信通知一下我~
      money: 100,
      obj: {
        name: '小花',
        age: 18
      }
    }
  },
  watch: {
    // 1. 监视简单类型
    // 提供数据变化的处理函数, newVal 变换后的值， oldValue之前的值
    'money' (newVal, oldVal) {
      console.log('尊敬的用户，您的银行卡余额变更为：', newVal, '原：', oldVal)
    },
    // 监视小花的年纪
    'obj.age' (newVal, oldVal) {
      console.log('小花，你变了，年纪:', newVal, '之前：', oldVal)
    }
  }
}
</script>

<style>

</style>