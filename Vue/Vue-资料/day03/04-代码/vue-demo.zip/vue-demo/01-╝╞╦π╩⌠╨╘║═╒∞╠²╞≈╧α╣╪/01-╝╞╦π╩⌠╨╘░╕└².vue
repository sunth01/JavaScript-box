<template>
  <div class="score-case">
    <div class="table">
      <table>
        <thead>
          <tr>
            <th>编号</th>
            <th>科目</th>
            <th>成绩</th>
            <th>考试时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody v-if="list.length > 0">
          <tr v-for="(item, index) in list" :key="item.id">
            <td>{{ index + 1 }}</td>
            <td>{{ item.subject }}</td>
            <td :class="{ red: item.score < 60 }">{{ item.score }}</td>
            <td>{{ format(item.date) }}</td>
            <td><a href="#" @click.prevent="del(item.id)">删除</a></td>
          </tr>
        </tbody>
        <tbody v-else>
          <tr>
            <td colspan="5">
              <span class="none">暂无数据</span>
            </td>
          </tr>
        </tbody>

        <tfoot>
          <tr>
            <td colspan="5">
              <span>总分：{{ total }}</span>
              <span style="margin-left:50px">平均分：{{ average }}</span>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
    <div class="form">
      <div class="form-item">
        <div class="label">科目：</div>
        <div class="input">
          <input v-model.trim="subject" type="text" placeholder="请输入科目" />
        </div>
      </div>
      <div class="form-item">
        <div class="label">分数：</div>
        <div class="input">
          <input v-model.number="score" type="text" placeholder="请输入分数" />
        </div>
      </div>
      <div class="form-item">
        <div class="label"></div>
        <div class="input">
          <button class="submit" @click="add">添加</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from 'moment'

// 结论：什么时候用计算属性？
// 场景1：求和，求总价...  基于数据运算求值的
// 场景2: ...

export default {
  name: 'ScoreCase',
  data () {
    return {
      list: [
        {id: 15, subject: '语文', score: 89, date: new Date('2022/06/07 10:00:00')},
        {id: 27, subject: '数学', score: 100, date: new Date('2022/06/07 15:00:00')},
        {id: 32, subject: '英语', score: 56, date: new Date('2022/06/08 10:00:00')},
        {id: 41, subject: '物理', score: 76, date: new Date('2022/06/08 10:00:00')}
      ],
      subject: '',  // 科目
      score: '' // 分数
    }
  },
  methods: {
    del (id) {
      // 根据 id 唯一标识（发请求 / 从数组直接删）
      // 删除某一id的项 => 过滤出所有不是该 id 的项  filter
      this.list = this.list.filter(item => item.id !== id)
    },

    add () {
      if (this.subject === '' || this.score > 100) {
        alert('请正确的录入成绩！')
        return
      }

      this.list.push({
        id: +new Date(), // 时间戳，数字类型，以时间戳作为唯一的id
        subject: this.subject,
        score: this.score,
        date: new Date() // 正常日期
      })
      // 清空内容
      this.subject = ''
      this.score = ''
    },

    format(date) {
      return moment(date).format('YYYY/MM/DD HH:mm:ss')
    }
  },

  // data 提供数据 methods 方法 computed 计算属性
  // 计算属性，也是属性，访问的原则 和 data中的属性访问原则一致
  computed: {
    // 写法上是一个函数，必须要有返回值
    total () {
      // arr.reduce((上一次累加的结果, 每一项, 下标) => {
      //   return 累加的结果
      // }, 起始累加值)

      const result = this.list.reduce((sum, item) => {
        return sum + item.score
      }, 0)

      return result
    },
    average () {
      const result = this.list.length > 0 ? this.total / this.list.length : 0
      return result.toFixed(2)
    }
  }
};
</script>

<style lang="less">
.score-case {
  width: 1000px;
  margin: 50px auto;
  display: flex;
  .table {
    flex: 4;
    table {
      width: 100%;
      border-spacing: 0;
      border-top: 1px solid #ccc;
      border-left: 1px solid #ccc;
      th {
        background: #f5f5f5;
      }
      tr:hover td {
        background: #f5f5f5;
      }
      td,
      th {
        border-bottom: 1px solid #ccc;
        border-right: 1px solid #ccc;
        text-align: center;
        padding: 10px;
        &.red {
          color: red;
        }
      }
    }
    .none {
      height: 100px;
      line-height: 100px;
      color: #999;
    }
  }
  .form {
    flex: 1;
    padding: 20px;
    .form-item {
      display: flex;
      margin-bottom: 20px;
      align-items: center;
    }
    .form-item .label {
      width: 60px;
      text-align: right;
      font-size: 14px;
    }
    .form-item .input {
      flex: 1;
    }
    .form-item input,
    .form-item select {
      appearance: none;
      outline: none;
      border: 1px solid #ccc;
      width: 200px;
      height: 40px;
      box-sizing: border-box;
      padding: 10px;
      color: #666;
    }
    .form-item input::placeholder {
      color: #666;
    }
    .form-item .cancel,
    .form-item .submit {
      appearance: none;
      outline: none;
      border: 1px solid #ccc;
      border-radius: 4px;
      padding: 4px 10px;
      margin-right: 10px;
      font-size: 12px;
      background: #ccc;
    }
    .form-item .submit {
      border-color: #069;
      background: #069;
      color: #fff;
    }
  }
}
</style>