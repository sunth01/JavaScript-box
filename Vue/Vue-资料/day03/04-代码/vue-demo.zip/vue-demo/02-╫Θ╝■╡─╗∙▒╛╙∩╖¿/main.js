import Vue from 'vue'
import App from './App.vue'
// 脚手架环境中，如果文件后缀名是 js 或 vue，可以省略后缀名
import HmButton from './components/hm-button.vue'
import ShuaiTest from './components/test.vue'

// 全局注册, 组件名推荐：大驼峰命名法
// 一旦一个组件全局注册了，在所有的组件实例中，都可以直接使用了
// Vue.component('HmButton', HmButton)

// Vue.component('hm-button', HmButton) // <hm-button></hm-button>
Vue.component('HmButton', HmButton) // <hm-button></hm-button> <HmButton></HmButton>
Vue.component('ShuaiTest', ShuaiTest)

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
