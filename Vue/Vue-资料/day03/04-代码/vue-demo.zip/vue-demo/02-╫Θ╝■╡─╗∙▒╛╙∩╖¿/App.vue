<template>
  <div>
    <!-- 拆解的角度：可以将大组件拆解成一个个小组件，便于维护 -->
    <HmHeader></HmHeader>
    <HmMain></HmMain>
    <HmFooter></HmFooter>

    <hm-button></hm-button>
  </div>
</template>

<script>
import HmHeader from './components/hm-header.vue'
import HmMain from './components/hm-main.vue'
import HmFooter from './components/hm-footer.vue'

export default {
  components: {
    // 组件名，推荐大驼峰命名法
    HmHeader: HmHeader,
    HmMain,
    HmFooter
  },
  data () {
    return {
      money: 100
    }
  }
}
</script>

<style>

</style>