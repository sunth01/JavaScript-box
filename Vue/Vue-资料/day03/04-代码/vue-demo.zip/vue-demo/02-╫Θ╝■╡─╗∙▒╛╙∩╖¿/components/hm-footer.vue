<template>
  <div class="hm-footer">
    <div>底部 - 100行</div>
    <hm-button></hm-button>
  </div>
</template>

<script>
export default {
  name: 'HmFooter'
}
</script>

<style lang="less">
.hm-footer {
  height: 100px;
  border: 3px solid #000;
  margin: 10px;
}
</style>