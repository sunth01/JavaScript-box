<template>
  <div class="hm-header">
    <div>头部 - 100行</div>
    <hm-button></hm-button>
  </div>
</template>

<script>
export default {
  name: 'HmHeader'
}
</script>

<style lang="less" scoped>
.hm-header {
  height: 150px;
  border: 3px solid #000;
  margin: 10px;
}
div {
  background-color: pink;
}
</style>