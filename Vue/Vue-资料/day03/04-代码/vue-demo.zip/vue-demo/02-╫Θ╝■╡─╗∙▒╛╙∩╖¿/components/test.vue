<template>
  <div>我是test组件</div>
</template>

<script>
export default {
  // name是组件的属性标识，决定了调试工作中组件的显示名字
  name: 'ShuaiTest'
}
</script>

<style scoped>

</style>