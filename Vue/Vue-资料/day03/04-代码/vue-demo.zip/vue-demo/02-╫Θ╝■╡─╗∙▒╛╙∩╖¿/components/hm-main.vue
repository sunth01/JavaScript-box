<template>
  <div class="hm-main">
    <div>内容 - 200行</div>
    <hm-button></hm-button>
    <ShuaiTest></ShuaiTest>
  </div>
</template>

<script>
export default {
  name: 'HmMain'
}
</script>

<style lang="less" scoped>
// 希望样式只作用于当前组件，且样式应该只作用于当前组件才行！组件的结构样式行为，独立！
// 组件中的样式：
// 1. 全局样式：默认组件的样式，会作用到全局，容易造成样式冲突
// 2. 局部样式：加了scoped后，样式只会作用于组件的范围内 （避免了组件样式冲突）

// 结论：推荐大家组件，都加上scoped属性
.hm-main {
  height: 400px;
  border: 3px solid #000;
  margin: 10px;
}

div {
  background-color: orange;
}
</style>