<template>
  <!-- 必须有且只能有一个根元素 -->
  <button>我是一个按钮</button>
</template>

<script>
export default {
  name: 'HmButton'
}
</script>

<style>
button {
  width: 150px;
  height: 40px;
  border: 3px solid #000;
  border-radius: 5px;
  background-color: blueviolet;
  color: white;
}
</style>