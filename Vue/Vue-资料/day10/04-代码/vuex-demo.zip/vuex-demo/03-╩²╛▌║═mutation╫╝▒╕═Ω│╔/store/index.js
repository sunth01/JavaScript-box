import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const store = new Vuex.Store({
  // 提供数据
  state: {
    count: 100
  },
  // 提供操作数据的方法
  mutations: {
    // 所有mutations函数中，第一个参数，都是state
    addOne (state) {
      state.count++
    },
    addN (state, payload) { // payload 额外参数
      state.count += payload
    },
    subOne (state) {
      state.count--
    },
    subN (state, payload) { // payload 额外参数
      state.count -= payload
    }
  }
})

export default store
