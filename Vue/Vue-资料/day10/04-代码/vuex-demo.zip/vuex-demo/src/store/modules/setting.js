export default {
  namespaced: true,
  state: {
    title: '最受欢迎的网站',
    info: '每日访问量3000+'
  },
  mutations: {},
  actions: {},
  getters: {}
}
