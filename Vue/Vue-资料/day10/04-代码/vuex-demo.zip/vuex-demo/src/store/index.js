import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user'
import setting from './modules/setting'
import cart from './modules/cart'
Vue.use(Vuex)

const store = new Vuex.Store({
  // 1. 提供数据
  state: {
    count: 100,
    list: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  },
  // 2. 提供操作数据的方法，且必须是同步的
  mutations: {
    // 所有mutations函数中，第一个参数，都是state
    addOne (state) {
      state.count++
    },
    addN (state, payload) { // payload 额外参数
      state.count += payload
    },
    subOne (state) {
      state.count--
    },
    subN (state, payload) { // payload 额外参数
      state.count -= payload
    },
    changeCount (state, payload) {
      state.count = payload
    }
  },
  // 3. 可以处理异步操作，但是不能直接修改数据
  actions: {
    // action支持异步操作，注意：actions中只能提交mutation，不能直接修改数据
    // 在所有的actions函数中，第一个参数ctx 上下文对象 （指代仓库）
    addWaitTime (ctx, payload) {
      setTimeout(() => {
        ctx.commit('addN', payload)
      }, 3000)
    }
  },
  // 4. 存放基于state的一些计算属性
  getters: {
    listLength (state) {
      return state.list.length
    },
    doubleCount (state) {
      return state.count * 2
    }
  },

  // 5. modules分模块
  modules: {
    user,
    setting,
    cart
  }
})

export default store
