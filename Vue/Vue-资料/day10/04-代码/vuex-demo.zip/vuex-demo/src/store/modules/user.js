// user模块 => 导出一个对象，对象中包含user模块的所有配置
export default {
  // 开启命名空间，保证不同模块的独立性
  namespaced: true,
  state: {
    username: '帅鹏',
    gender: '男',
    token: 'euersdueryy3ttyrwy'
  },
  mutations: {
    // state直接指向当前模块的state状态
    setUserName (state, payload) {
      state.username = payload
    }
  },
  actions: {},
  getters: {
    bigName (state) {
      return '宇宙无敌-' + state.username
    }
  }
}
