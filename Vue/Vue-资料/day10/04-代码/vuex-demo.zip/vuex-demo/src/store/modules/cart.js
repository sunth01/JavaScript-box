export default {
  namespaced: true,
  state: {
    list: []
  },
  mutations: {},
  actions: {},
  getters: {}
}
