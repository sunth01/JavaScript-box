<template>
  <div class="box">
    <h2>子组件 add</h2>
    从vuex中获取的值:<label>{{ count }}</label>
    <br />
    <button @click="addOne">值+1</button>
    <button @click="addN(2)">值+2</button>
    <button @click="addN(3)">值+3</button>
    <button @click="fn">值+5 (3秒后)</button>
  </div>
</template>

<script>
import { mapActions, mapMutations, mapState } from 'vuex'
export default {
  name: 'AddItem',
  computed: {
    ...mapState(['count'])
  },
  methods: {
    ...mapMutations(['addOne', 'addN']),
    ...mapActions(['addWaitTime']),
    fn () {
      // this.addWaitTime(5)

      // 调用action：this.$store.dispatch('action名字', 额外传参)
      this.$store.dispatch('addWaitTime', 5)
    }
  }
}
</script>

<style lang="css" scoped>
.box {
  border: 3px solid #ccc;
  width: 400px;
  padding: 10px;
  margin: 20px;
}
h2 {
  margin-top: 10px;
}
</style>
