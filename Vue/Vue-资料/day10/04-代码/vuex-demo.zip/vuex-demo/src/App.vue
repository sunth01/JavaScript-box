<template>
  <div id="app">
    <h1>根组件 - {{ count }}</h1>
    <!-- v-model连招 =>  :value  和  @input -->
    <input :value="count" @input="handleInput" type="text">
    <add-item></add-item>
    <hr>
    <sub-item></sub-item>
    <p>getters, listLength: {{ $store.getters.listLength }}</p>
    <p>getters, doubleCount: {{ doubleCount }}</p>
    <hr>
    <!-- 尽管已经分模块了，但是其实子模块的状态，还是会被挂载到根级别的state中, 属性名就是模块名 -->
    <p>user模块username: {{ $store.state.user.username }}</p>
    <p>user模块gender: {{ $store.state.user.gender }}</p>
    <p>user模块username: {{ username }}</p>
    <p>user模块gender: {{ gender }}</p>
    <hr>
    <p>getters-bigName: {{ $store.getters['user/bigName'] }}</p>
    <p>getters-bigName: {{ bigName }}</p>
    <hr>
    <button @click="changeFn">修改user模块的username</button>
  </div>
</template>

<script>
import { mapGetters, mapMutations, mapState } from 'vuex'
import AddItem from './components/add-item.vue'
import SubItem from './components/sub-item.vue'
export default {
  name: 'app',
  computed: {
    // 根级别的状态映射
    ...mapState(['count']),
    ...mapGetters(['doubleCount']),

    // 子模块的状态映射
    // ...mapState(模块名, ['属性名'])
    ...mapState('user', ['username', 'gender']),
    ...mapGetters('user', ['bigName'])
  },

  created () {
    console.log(this.$store.state)
    console.log(this.$store.state.user.username)

    console.log(this.$store.getters)
    console.log(this.$store.getters['user/bigName'])
  },

  components: {
    AddItem,
    SubItem
  },
  methods: {
    // 往methods里面新增了一个函数，changeCount
    // 根级别的方法映射
    ...mapMutations(['changeCount']),
    // 子模块的方法映射
    ...mapMutations('user', ['setUserName']),

    handleInput (e) {
      // console.log(e.target.value)
      // this.$store.commit('changeCount', +e.target.value)

      this.changeCount(+e.target.value)
    },

    // getters state 辅助函数使用居多
    // mutations actions 原生语法使用居多
    changeFn () {
      // 原生语法(强烈推荐)
      // this.$store.commit('模块名/mutation名', 额外传参)
      // this.$store.commit('user/setUserName', '大大帅')

      this.setUserName('小小鹏')
    }
  }
}

// actions的使用类似于mutations
// 1. 提供actions
// 2. 页面中dispatch
//    (1) 原生：this.$store.dispatch('模块名/action名', 额外传参)
//    (2) 辅助：...mapActions(模块名, ['函数名'])
//              this.函数名()
</script>

<style>
#app {
  width: 600px;
  margin: 20px auto;
  border: 3px solid #ccc;
  border-radius: 3px;
  padding: 10px;
}
</style>
