<template>
  <div class="box">
    <h2>子组件 sub</h2>
    从vuex中获取的值: <label>{{ count }} - {{ car }}</label>
    <br>
    <button @click="subOne">值-1</button>
    <button @click="subN(2)">值-2</button>
    <button @click="subN(3)">值-3</button>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
export default {
  name: 'SubItem',
  computed: {
    ...mapState(['count', 'car'])
  },
  // methods: {
  //   subOne () {
  //     this.$store.commit('subOne')
  //   },
  //   subN(n) {
  //     this.$store.commit('subN', n)
  //   }
  // }
  methods: {
    ...mapMutations(['subOne', 'subN']),
    fn () {
      console.log(123)
    }
  }
}
</script>

<style lang="css" scoped>
.box{
  border: 3px solid #ccc;
  width: 400px;
  padding: 10px;
  margin: 20px;
}
h2 {
  margin-top: 10px;
}
</style>
