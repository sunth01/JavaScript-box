<template>
  <div class="box">
    <h2>子组件 add</h2>
    从vuex中获取的值:<label>{{ count }}</label>
    <br />
    <button @click="addOne">值+1</button>
    <button @click="addN(2)">值+2</button>
    <button @click="addN(3)">值+3</button>
  </div>
</template>

<script>
import { mapMutations, mapState } from 'vuex'
export default {
  name: 'AddItem',
  computed: {
    ...mapState(['count'])
  },
  methods: {
    ...mapMutations(['addOne', 'addN'])

    // add () {
    //   // console.log(this.count) // 获取的是自己的计算属性
    //   // console.log(this.$store.state.count) // 原生语法：直接拿仓库的本源数据

    //   // 修改数据（vuex的数据只有vuex能改，不要在vuex mutation之外修改数据）
    //   // vuex同样要遵循单向数据流
    //   // this.$store.state.count++ // 错误写法

    //   // 提交调用mutation函数语法：
    //   // this.$store.commit('mutation名字', 额外传参)
    //   this.$store.commit('addOne')
    // },

    // addN (value) {
    //   // 提交调用仓库的 addN mutation函数，并且传递参数 value
    //   // this.$store.commit('addN', {
    //   //   count: 1000,
    //   //   msg: '嘎嘎标题'
    //   // })

    //   this.$store.commit('addN', value)
    // }
  }
}
</script>

<style lang="css" scoped>
.box {
  border: 3px solid #ccc;
  width: 400px;
  padding: 10px;
  margin: 20px;
}
h2 {
  margin-top: 10px;
}
</style>
