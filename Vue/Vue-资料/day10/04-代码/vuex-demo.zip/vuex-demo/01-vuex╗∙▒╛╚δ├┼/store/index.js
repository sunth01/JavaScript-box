// 和仓库相关的逻辑 都写在  store/index.js 中
// 导包
import Vue from 'vue'
import Vuex from 'vuex'

// use使用
Vue.use(Vuex)

// 创建仓库 (创建了一个空仓库) 基于 Vuex里面的Store构造函数，创建仓库实例
const store = new Vuex.Store({
  // 1. state: 存放数据
  //    state 状态，可以用于提供数据，类似于vue组件中的data
  //    区别在于，data是组件自己的数据，state是整个项目所有组件共享的数据
  state: {
    count: 100,
    msg: 'vuex学习',
    car: '宝马'
  },

  // 2. mutations: 存放操作数据的方法
  mutations: {
    // 提供了一个修改数据方法 addOne 就是一个 mutation函数
    // 任何地方，如果要修改vuex数据，必须调用到 mutation 函数
    // 所有mutation函数，第一个形参都是state状态
    addOne (state) {
      state.count++
    },

    // payload额外参数，可以接收到提交时携带的参数 （但是一次提交，只能携带一个参数）
    addN (state, payload) {
      // console.log(payload)
      // state.count = payload.count
      // state.msg = payload.msg
      state.count += payload
    },

    subOne (state) {
      state.count--
    },

    subN (state, payload) {
      state.count -= payload
    }
  },

  // 开启严格模式：规范化代码操作，对于不规范的vuex数据操作，直接报错
  // 默认不开启，开启会消耗监听性能
  strict: true
})

// 导出
export default store
