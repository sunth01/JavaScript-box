<template>
  <div id="app">
    <!--
      注意：要获取仓库的数据，先要找仓库，到了仓库，才能拿仓库的数据
      如何获取仓库？联想获取路由
      组件实例范围，this指向vue实例 => this.$router   &  this.$store
      普通js环境，this不指向vue实例 => 引包获取router  &  引包获取store
    -->
    <h1>根组件 - {{ count }} {{ msg }} {{ car }}</h1>
    <input type="text">
    <add-item></add-item>
    <hr>
    <sub-item></sub-item>
  </div>
</template>

<script>
import AddItem from './components/add-item.vue'
import SubItem from './components/sub-item.vue'
import { mapState } from 'vuex'

// 辅助函数:
// 1. mapState辅助函数, 可以映射state状态，生成组件的计算属性
// 2. mapMutations辅助函数，可以映射mutation函数，生成组件的函数

export default {
  name: 'app',
  // 依赖于一些数据，动态计算出一些属性，依赖的数据一旦变化，自动重新计算
  // vuex提供了辅助函数，帮你辅助开发，可以快速生成计算属性
  // computed: {
  //   count () {
  //     return this.$store.state.count
  //   },
  //   msg () {
  //     return this.$store.state.msg
  //   }
  // },
  // 问题：mapState将整个computed占据了，无法提供自己组件内的计算属性 => 不合理
  computed: {
    // 自己的计算属性
    title () {
      return '大标题'
    },
    // 将mapState生成的对象，进行展开，将所有展开的属性，作为computed的子属性
    ...mapState(['count', 'msg', 'car'])
  },
  components: {
    AddItem,
    SubItem
  }
}
</script>

<style>
#app {
  width: 600px;
  margin: 20px auto;
  border: 3px solid #ccc;
  border-radius: 3px;
  padding: 10px;
}
</style>
