<template>
  <!-- 底部部分 => list有数据的时候，才展示  list.length > 0 -->
  <footer v-if="list.length > 0" class="footer">
    <span class="todo-count"><strong>{{ leftCounts }}</strong>剩余</span>
    <ul class="filters">
      <li>
        <a @click="filter('all')" 
          :class="{ selected: type === 'all' }" href="#/">全部</a>
      </li>
      <li>
        <a @click="filter('active')" 
          :class="{ selected: type === 'active' }" href="#/active">进行中</a>
      </li>
      <li>
        <a @click="filter('completed')" 
          :class="{ selected: type === 'completed' }" href="#/completed">已完成</a>
      </li>
    </ul>
    <!-- 有已完成的任务，才需要显示这个按钮 -->
    <button v-if="isShowClear" @click="clear" class="clear-completed">清除已完成</button>
  </footer>
</template>

<script>
export default {
  props: {
    list: Array,
    type: String
  },
  computed: {
    // 根据数据，动态计算得到一些值 => 计算属性
    // 未完成的数量
    leftCounts () {
      return this.list.filter(item => item.flag === false).length
    },
    // 是否显示 - 清除已完成的按钮
    isShowClear () {
      // 只要有一个已完成，就可以显示按钮 some
      return this.list.some(item => item.flag === true)
    }
  },
  methods: {
    clear () {
      // 子传父, 子组件触发事件
      this.$emit('clear')
    },
    filter (type) {
      // this.type = type
      this.$emit('changeType', type)
    }
  }
}
</script>

<style></style>
