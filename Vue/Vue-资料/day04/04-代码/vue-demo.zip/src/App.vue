<template>
  <section class="todoapp">
    <hm-header @add="handleAdd"></hm-header>
    <hm-main @changeAll="changeAll" @del="handleDel" @changeState="handleChangeState" :list="showList"></hm-main>
    <hm-footer @changeType="changeType" @clear="handleClear" :list="list" :type="type"></hm-footer>
  </section>
</template>

<script>
import HmHeader from './components/hm-header.vue'
import HmMain from './components/hm-main.vue'
import HmFooter from './components/hm-footer.vue'
export default {
  components: {
    HmHeader,
    HmMain,
    HmFooter
  },
  data () {
    return {
      // 这个list是原始的，完整的数据，给子组件传的数据，没必要是完整的数据
      // 给用户展示的，只需要是过滤后的数据即可 showList
      list: JSON.parse(localStorage.getItem('todoList')) || [],
      type: 'all' // 过滤条件
    }
  },
  computed: {
    // 给用户看的数据，基于原始数据 和 过滤条件计算得到的
    showList () {
      if (this.type === 'all') {
        return this.list
      } else if (this.type === 'active') {
        // 过滤出未完成的展示
        return this.list.filter(item => item.flag === false)
      } else {
        // 过滤出已完成的展示
        return this.list.filter(item => item.flag === true)
      }
    }
  },
  methods: {
    changeAll (flag) {
      // 让list中的所有的任务，和flag同步
      this.list.forEach(item => item.flag = flag)
    },
    handleDel (id) {
      // console.log('子传父，传递了 id', id)
      // 过滤
      this.list = this.list.filter(item => item.id !== id)
    },
    handleAdd (value) {
      // 往数组的最前面，添加一项  更新视图 => 修改数据
      this.list.unshift({
        id: +new Date(),
        name: value,
        flag: false
      })
    },
    handleChangeState (flag, id) {
      // 根据 id 找到数组中的对应项，进行更新 find
      const obj = this.list.find(item => item.id === id)
      obj.flag = flag
    },
    handleClear () {
      // 保留所有未完成的
      this.list = this.list.filter(item => item.flag === false)
    },
    changeType (type) {
      this.type = type
    }
  },
  watch: {
    list: {
      deep: true,
      handler (newValue) {
        // 存本地之前，先转 JSON
        localStorage.setItem('todoList', JSON.stringify(newValue))
      }
    }
  }
}
</script>

<style></style>
