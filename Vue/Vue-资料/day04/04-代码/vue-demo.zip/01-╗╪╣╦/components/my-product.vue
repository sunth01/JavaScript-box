<template>
  <div class="product">
    <h3>标题：{{ title }}</h3>
    <p>价格: {{ price }} 元一根</p>
    <p>描述: {{ info }}  <button @click="sayPrice">砍一刀 - {{ pid }}</button></p>
  </div>
</template>

<script>
export default {
  // 这里的name 和 注册的名字要统一，推荐使用大驼峰
  name: 'MyProduct',

  // props接收到的数据，和data一样，可以直接在模板或者methods等方法中使用
  props: ['title', 'price', 'info', 'pid'],

  methods: {
    sayPrice () {
      // console.log(this.price)
      // 父组件传递过来的prop数据，是只读的，子组件不能够直接修改父组件传递过来的数据
      // this.price = this.price - 10

      // 发起砍价的申请，触发事件
      this.$emit('sayPrice', 10, this.pid)
    }
  }
}
</script>

<style lang="less" scoped>
.product {
  width: 400px;
  border: 3px solid #000;
  border-radius: 5px;
  margin: 10px;
  padding: 0 20px;
}
</style>