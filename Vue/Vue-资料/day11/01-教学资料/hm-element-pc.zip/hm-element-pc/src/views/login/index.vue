<template>
  <div class="login-page">
    <!--
      element-ui表单校验注意点：
      1. 给表单元素设置
         准备一个对象数据，将数据中的属性，要和表单元素 v-model 绑定
         v-model

      2. 给 el-form 设置
         :model="对象数据"  将表单元素中绑定的对象，给el-form，决定校验谁
         :rules="校验规则"  配置，对于这个对象，应该如何校验

      3. 给 el-form-item 配置 (容易漏)
         prop属性，prop="字段名"
     -->
    <el-card>
      <template #header>黑马面经运营后台</template>

      <el-form ref="form" :model="form" :rules="rules" autocomplete="off">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" placeholder="输入用户名"></el-input>
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input v-model="form.password" type="password" placeholder="输入用户密码"></el-input>
        </el-form-item>

        <el-form class="tc">
          <el-button type="primary" @click="login">登 录</el-button>
          <el-button @click="reset">重 置</el-button>
        </el-form>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { login } from '@/api/user.js'
import { Message } from 'element-ui'

export default {
  name: 'login-page',
  data () {
    return {
      form: {
        username: '',
        password: ''
      },
      rules: {
        // 字段
        username: [
          // trigger触发校验的时机: 'blur'失去焦点 / 'change'值改变
          { required: true, message: '请输入用户名', trigger: ['blur', 'change'] },
          { min: 5, max: 11, message: '用户名长度为 5-11 位', trigger: ['blur', 'change'] }
        ],
        // /^\d{11}$/   11位手机号
        // /^\w{5,11}$/  可以出现5-11位的字符 （字母数字下滑线）
        password: [
          { required: true, message: '请输入密码', trigger: ['blur', 'change'] },
          { pattern: /^\w{5,11}$/, message: '密码必须是5-11位的字符', trigger: ['blur', 'change'] }
        ]
      }
    }
  },
  methods: {
    async login () {
      // console.log('该发送请求了', this.form)
      // console.log(this.$refs.form)
      // validate: 对整个表单进行校验
      try {
        await this.$refs.form.validate()
        // 能到这里，说明通过了校验，一定返回值是 true
        // console.log('该发送请求了', this.form)
        try {
          const res = await login(this.form)
          // 由于token的使用频率很高使用频率很高，一般将token都会存入vuex
          // 将token存入vuex
          this.$store.commit('user/setToken', res.data.token)
          Message.success('登录成功')
          this.$router.push('/')
        } catch (e) {
          // Message => vant中的Toast
          Message.error('用户名或者密码错误')
        }
      } catch (e) {
        console.log('校验错误信息:', e)
      }
    },

    reset () {
      this.$refs.form.resetFields()
    }
  }
}
</script>

<style lang="scss" scoped>
.login-page {
  min-height: 100vh;
  background: url(@/assets/login-bg.svg) no-repeat center / cover;
  display: flex;
  align-items: center;
  justify-content: space-around;
  .el-card {
    width: 420px;
    ::v-deep .el-card__header{
      height: 80px;
      background: rgba(114,124,245,1);
      text-align: center;
      line-height: 40px;
      color: #fff;
      font-size: 18px;
    }
  }
  .el-form {
    padding: 0 20px;
  }
  .tc {
    text-align: center;
  }
}
</style>
