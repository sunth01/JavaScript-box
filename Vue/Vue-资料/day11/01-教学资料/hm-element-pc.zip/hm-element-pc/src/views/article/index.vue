<template>
  <div class="article-page">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item>面经后台</el-breadcrumb-item>
      <el-breadcrumb-item>面经管理</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card shadow="never" border="false">
      <template #header>
        <div class="header">
          <span>共 {{ total }} 条记录</span>
          <el-button @click="openDrawer('add')" icon="el-icon-plus" size="small" type="primary" round>
            添加面经
          </el-button>
        </div>
      </template>

      <!-- 表格主体  对象数组 => [{}, {}, {}],  字符串数组 => ['abc', 'cdj']\
           1 el-table 整个表格
             :data="数组源"  对象数组（后台返回）

           2 el-table-column 表格的列
             prop: 写数据源的对象中的键名， 决定列的渲染数据
             label: 定义列名字
             width: 宽度

             表格的列的内容，有两种配置方式：
             1. 配置prop，通过数据做渲染
             2. 通过默认插槽
      -->
      <el-table :data="list" style="width: 100%">
        <el-table-column prop="stem" label="标题" width="400"></el-table-column>
        <el-table-column prop="creator" label="作者"></el-table-column>
        <el-table-column prop="likeCount" label="点赞"></el-table-column>
        <el-table-column prop="views" label="浏览数"></el-table-column>
        <el-table-column prop="createdAt" label="更新时间"></el-table-column>

        <!-- 难点：我们用的是他封装好的表格，渲染v-for这个过程，是在表格组件内部实现
             如果要拿到id，相当于使用组件时，要用到组件内部的数据，其实插槽也是可以传值的
        -->
        <el-table-column label="操作">
          <!-- obj.row => 就是遍历的每一项, 但凡用到element的列，都可以直接通过作用域插槽row拿到每一行的数据 -->
          <!--
              <xx v-for="item in list" :key="item.id">
                <slot :row="item"></slot>
              </xx>
           -->
          <template #default="{ row }">
            <div class="actions">
              <i class="el-icon-view" @click="openDrawer('preview', row.id)"></i>
              <i class="el-icon-edit-outline" @click="openDrawer('edit', row.id)"></i>
              <i class="el-icon-delete" @click="del(row.id)"></i>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页
           1. @current-change="handleCurrentChange" 处理当前页的变化
           2. :current-page 生效的当前页
           3. :page-size    生效的每页条数
           4. :total        总条数
           5. layout        布局容器
      -->
      <el-pagination
        @current-change="handleCurrentChange"
        background
        :current-page="current"
        :page-size="pageSize"
        layout="prev, pager, next"
        :total="total">
      </el-pagination>
    </el-card>

    <!--
      1 :visible.sync="布尔值" 控制抽屉的显示隐藏， 传入true显示，传入false隐藏
      2 direction 指定抽屉打开的位置方向  rtl 右边打开
      3 before-close 处理抽屉的关闭监听
    -->
    <el-drawer
      :title="drawerTitle"
      :visible.sync="isShowDrawer"
      direction="rtl"
      size="50%"
      :before-close="handleClose">

      <!-- el-form  el-form-item el-input -->
      <!--
        el-form校验:
          1. 准备一个对象，让对象的属性 和 表单元素 v-model 绑定
          2. 给el-form设置
             :model="数据对象"  告诉el-form校验要校验，校验哪个对象
             :rules="校验规则"  告诉el-form校验的规则是啥，怎么校验
          3. 给el-form-item设置
             prop="字段名"  （容易漏）
       -->

      <div v-if="drawerType === 'preview'" class="article-preview">
        <h5>{{ form.stem }}</h5>
        <div v-html="form.content"></div>
      </div>

      <el-form v-else ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="标题" prop="stem">
          <el-input v-model="form.stem" placeholder="请输入面经标题"></el-input>
        </el-form-item>

        <el-form-item label="内容" prop="content">
          <!-- 富文本编辑器  第三方的插件，组件需要单独注册 -->
          <!-- quill-editor不是element的表单控件，他的失去焦点，不是el-form能直接监听到的 -->
          <quill-editor @blur="$refs.form.validateField('content')" v-model="form.content"></quill-editor>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submit">确认</el-button>
          <el-button @click="handleClose">取消</el-button>
        </el-form-item>
      </el-form>
    </el-drawer>
  </div>
</template>

<script>
import { createArticle, getArticleDetail, getArticleList, removeArticle, updateArticle } from '@/api/article'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'
export default {
  name: 'article-page',
  components: {
    quillEditor
  },
  data () {
    return {
      list: [], // 存放对象数组
      total: 0, // 总条数
      current: 1, // 当前页
      pageSize: 10, // 每页条数
      isShowDrawer: false, // 默认不显示
      drawerType: '',
      form: {
        stem: '', // 标题
        content: '' // 内容
      },
      rules: {
        stem: [{ required: true, message: '请输入标题', trigger: 'blur' }],
        content: [{ required: true, message: '请输入标题', trigger: 'blur' }]
      }
    }
  },
  created () {
    // 一进入页面就发请求
    this.initData()
  },
  computed: {
    drawerTitle () {
      if (this.drawerType === 'add') {
        return '添加面经'
      } else if (this.drawerType === 'preview') {
        return '预览面经'
      } else {
        return '编辑面经'
      }
    }
  },
  methods: {
    async initData () {
      const { data } = await getArticleList({
        current: this.current,
        pageSize: this.pageSize
      })
      this.total = data.total
      this.list = data.rows
      console.log(this.list)
    },
    async del (id) {
      // console.log(id)
      await removeArticle(id)
      this.$message.success('删除成功')
      this.initData()
    },
    handleCurrentChange (val) {
      // val 点击页码，得到的变化后的页码值
      // 1. 更新当前页
      this.current = val
      // 2. 重新初始化渲染
      this.initData()
    },
    // 打开抽屉的方法
    async openDrawer (type, id) {
      this.isShowDrawer = true
      this.drawerType = type // 将当前打开的抽屉类型记录下来，add preview edit

      // preview 和 edit 都需要回显
      if (type !== 'add') {
        const res = await getArticleDetail(id)
        this.form = {
          ...res.data
        }
      }
    },
    // 关闭抽屉的方法
    handleClose () {
      // 对于预览而言，没有form表单
      // if (this.$refs.form) this.$refs.form.resetFields()
      // 链式运算符: 进行链式获取时，经常容易报错，利用 ?. 可以减少错误的抛出
      this.$refs.form?.resetFields()
      this.isShowDrawer = false
    },
    async submit () {
      try {
        await this.$refs.form.validate()

        if (this.drawerType === 'add') {
          // 能到这里说明校验通过，发送请求进行提交
          await createArticle(this.form)
          this.$message.success('添加成功')
          // 重新渲染第一页
          this.current = 1
        }

        if (this.drawerType === 'edit') {
          const { stem, content, id } = this.form
          await updateArticle({ stem, content, id })
          this.$message.success('修改成功')
        }

        this.initData() // 重新渲染
        this.handleClose() // 调用方法，关闭弹框
      } catch (e) {
        console.log(e)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.el-card {
  margin-top: 25px;
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-right: 16px;
  }
  .actions {
    font-size: 18px;
    display: flex;
    justify-content: space-around;
    color: #666;
    > i:hover {
      color: rgba(114, 124, 245, 1);
      cursor: pointer;
    }
  }
}
.el-pagination {
  margin-top: 20px;
  text-align: center;
}
.el-breadcrumb {
  margin-top: 10px;
}
.el-form {
  padding-right: 40px;
}
.quill-editor {
  ::v-deep .ql-editor {
    height: 300px;
  }
}
.el-rate {
  padding: 10px 0;
}
.article-preview {
  padding: 0 40px 40px 40px;
  > h5 {
    font-size: 20px;
    color: #666;
    border-bottom: 1px dashed #ccc;
    padding-bottom: 30px;
    margin: 0 0 20px 0;
  }
}
</style>
