import Vue from 'vue'
import VueRouter from 'vue-router'
// 导入文件夹，如果要加载的是文件夹内， index.vue 或 index.js 可以省略
import Login from '@/views/login'
import Layout from '@/views/layout'
import Article from '@/views/article'
import Dashboard from '@/views/dashboard'
import store from '@/store'

Vue.use(VueRouter)

// 配置规则 + 准备出口 => 页面输入路径测试
const router = new VueRouter({
  routes: [
    { path: '/login', component: Login },
    {
      path: '/',
      component: Layout,
      redirect: '/dashboard',
      children: [
        // 如果子路由的 path，不是以 / 开头，视为相对路径 => 自动拼上父路由的路径
        { path: 'dashboard', component: Dashboard },
        { path: 'article', component: Article }
      ]
    }
  ]
})

// 全局前置守卫：所有的路由在真正被访问到之前，都会先经过全局前置守卫
// 只有守卫放行了，才能到达想去的页面

// 对于目前的系统：只分两种页面 => 登录 + 非登录（需要验证token）
// router.beforeEach((to, from, next) => {
//   const token = store.state.user.token
//   // 如果去的是登录，直接放行
//   if (to.path === '/login') {
//     next()
//   } else {
//     // 如果去的是非登录，需要验证token，有token放行，无token拦截
//     if (token) {
//       next()
//     } else {
//       next('/login')
//     }
//   }
// })

// 需要拦截的情况 => 进行拦截   其他情况正常放行
// 1. 要访问需要授权的页面，非登录页
// 2. 且无token
router.beforeEach((to, from, next) => {
  const token = store.state.user.token
  if (to.path !== '/login' && !token) return next('/login')
  // 其他情况, 正常放行
  next()
})

export default router
