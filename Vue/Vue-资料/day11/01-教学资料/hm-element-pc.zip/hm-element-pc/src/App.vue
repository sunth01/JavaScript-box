<template>
  <div id="app">
    <!-- <el-button type="primary" plain>蓝色镂空</el-button>
    <el-button type="success" round>绿色圆角</el-button>
    <el-button type="danger" circle>红色radius50%</el-button> -->
    <router-view></router-view>
  </div>
</template>

<style lang="scss">

</style>
