import { delToken, getToken, setToken } from '@/utils/storage'

// 每个子模块，有个各自的核心概念
export default {
  namespaced: true,
  state: {
    token: getToken() // 初始化的状态，是从本地读取的
  },
  mutations: {
    // 将来页面中，this.$store.commit('user/setToken', 新token)
    setToken (state, payload) {
      // 更新token状态
      state.token = payload
      // 同步到本地
      setToken(state.token)
    },

    logout (state) {
      // 清除token
      state.token = null
      // 清空本地
      delToken()
    }
  },
  actions: {},
  getters: {}
}
