import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user'
Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    user
  }
  // 限制那些不懂规范的人 => 我们是懂规范 => 不需要vue耗费性能监听，给我们报错
  // strict: true
})

export default store
