import request from '@/utils/request'

// request.get(url, {
//    params: {}, // 一般get配params，params在地址栏
//    data: {},   // 一般get不配data，data是在请求体
//    headers: {} // 通过请求拦截器，统一配置
// })
// request.delete(url, config)

// request.post(url, data, config)
// request.put(url, data, config)
// request.patch(url, data, config)

// 获取接口
// data => { current, pageSize }
// current: 当前页
// pageSize: 每页多少条
export const getArticleList = (data) => {
  return request.get('/admin/interview/query', {
    params: data
  })
}

// 添加接口
// data => { stem, content }
// stem 标题
// content 内容
export const createArticle = (data) => {
  return request.post('/admin/interview/create', data)
}

// 删除接口
export const removeArticle = id => {
  return request.delete('/admin/interview/remove', {
    params: {}, // 地址栏的参数（此处无）
    data: { // 请求体需要携带的参数
      id
    },
    headers: {} // 请求头需要写到的东西（此处无）
  })
}

// 获取单个文章详情
export const getArticleDetail = (id) => {
  return request.get('/admin/interview/show', {
    params: {
      id
    }
  })
}

// 修改提交更新
// data => { id, stem, content }
export const updateArticle = (data) => {
  return request.put('/admin/interview/update', data)
}
