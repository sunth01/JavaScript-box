<template>
  <div>我是数据看板页</div>
</template>

<script>
export default {
  name: 'DashboardIndex'
}
</script>

<style>

</style>
