<template>
  <div class="login-page">
    <el-card class="my-card">
      <!-- header插槽 -->
      <template #header>黑马面经运营后台</template>
      <!-- 默认插槽 -->
      <!-- el-form 整个form组件
           el-form-item 表单域, 一行, 可以存放格式类型的表单元素
           el-input 文本框
      -->
      <el-form>
        <el-form-item label="用户名">
          <el-input placeholder="请输入用户名"></el-input>
        </el-form-item>

        <el-form-item label="密码">
          <el-input placeholder="请输入密码"></el-input>
        </el-form-item>

        <el-form-item class="tc">
          <el-button type="primary">登录</el-button>
          <el-button>重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'LoginIndex'
}
</script>

<style lang="scss" scoped>
.login-page {
  min-height: 100vh;
  background: url(@/assets/login-bg.svg) no-repeat center / cover;
  // 利用flex水平垂直居中
  display: flex;
  justify-content: center;
  align-items: center;
  .el-card {
    width: 420px;
    ::v-deep .el-card__header{
      height: 80px;
      background: rgba(114,124,245,1);
      text-align: center;
      line-height: 40px;
      color: #fff;
      font-size: 18px;
    }
  }
  .el-form {
    padding: 0 20px;
  }
  .tc {
    text-align: center;
  }
}
// scoped会给下面的所有的类, 新增属性选择器, 可以增加一定的权重
// 如何给组件标签, 设置样式?
// 1. 给组件标签, 加<自定义类>
//    添加的类, 会自动加上渲染出来的组件的根元素上
// .my-card {
//   width: 420px;
//   margin: 0 auto;
// }

// 2. 直接使用<组件标签名>, 作为<类名>控制样式
//    组件库定义组件的规范: 声明的所有组件的根元素, 都有一个和组件名同名的类名(提供给你了)

// 加上scoped, 可以让样式, 只作用于当前组件模板(局部样式)
// 默认scoped样式, 不会向下渗透, 影响到其他子组件的(除了根元素)
// 如果希望样式, 可以向下渗透, 影响到下面的子孙后代, 就需要用到深度作用选择器(vue提供)

// 深度作用选择器:
// ::v-deep   scss
// /deep/     less
// .el-card {
//   width: 420px;
//   margin: 0 auto;
//   // 原理: 一旦选择器前面有深度作用标识, 就会不会附加属性选择器的限制
//   ::v-deep .el-card__header {
//     background-color: #727cf5;
//     text-align: center;
//     color: #fff;
//   }
// }

</style>
