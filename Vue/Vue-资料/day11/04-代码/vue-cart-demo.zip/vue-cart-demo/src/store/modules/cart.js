// 子模块其实就是一个对象，包含了 state mutations actions getters 配置项
// 需要配置 namespaced: true
import axios from 'axios'

// 注意：模块架完一定要去调试工具中确认，挂载无问题！
export default {
  namespaced: true,
  // 子模块中，推荐：使用一个工厂函数，在工厂函数中，返回一个对象数据
  // 两个语法皆可，知道即可
  state () {
    return {
      list: []
    }
  },
  mutations: {
    setList (state, payload) {
      state.list = payload
    },
    setCount (state, payload) {
      // payload => { id, count }
      // 根据 id 更新对应项的 count
      const obj = state.list.find(item => item.id === payload.id)
      obj.count = payload.count
    }
  },
  actions: {
    // action中《异步》获取数据，然后 commit 更新state的数据
    async getList (ctx) {
      const res = await axios.get('http://localhost:3000/cart')
      ctx.commit('setList', res.data)
    },
    async updateCount (ctx, payload) {
      // 处理异步
      // 基于payload发送请求，更新服务器端的 对应id项 的count
      // console.log(payload)
      await axios.patch(`http://localhost:3000/cart/${payload.id}`, {
        count: payload.count
      })
      // 执行到这，说明服务器已经更新，但是本地vuex数据没有更新
      // 两种做法（都对）
      // 1. 再次请求一下后台，更新到本地（发一次请求）
      //    如果数据是多个管理员可以维护操作的，建议发送请求
      //    调用自己模块的getList action，获取数据，渲染
      // ctx.dispatch('getList')

      // 2. 直接本地操作，更新数据
      //    好处：少发一次请求。提升性能
      //    缺点：有可能出现脏数据（错误无效的数据）
      //          本地手动修改数据，后台的更新, 可能没及时拿到，本地的就是无效数据
      ctx.commit('setCount', payload)
    }
  },
  getters: {
    total (state) {
      // list中所有的count累加
      // sum 前一次累加的结果，（第一次）就是后面给的初始值
      // 函数中，需要 return 当前累加的结果，结果会给到下一次执行函数的sum
      const result = state.list.reduce((sum, item) => {
        return sum + item.count
      }, 0)
      return result
    },
    totalPrice (state) {
      const result = state.list.reduce((sum, item) => {
        return sum + item.count * item.price
      }, 0)
      return result
    }
  }
}

// json-server起的服务器
// 1. 查询
// 接口地址：http://localhost:3000/cart
// 请求方式：get

// 2. 修改（部分）
// 接口地址：http://localhost:3000/cart/:id
// 请求方式：patch
// 请求参数：传个对象，对象的键，就是要修改的键
