<template>
  <div class="layout-page">
    首页架子 - 内容区域

    底部tabbar - 区域
  </div>
</template>

<script>
export default {
  name: 'layout-page'
}
</script>

<style lang="less" scoped></style>
