<template>
  <div class="register-page">
    注册页
  </div>
</template>

<script>
export default {
  name: 'register-page',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
.link {
  color: #069;
  font-size: 12px;
  padding-right: 20px;
  float: right;
}
</style>
