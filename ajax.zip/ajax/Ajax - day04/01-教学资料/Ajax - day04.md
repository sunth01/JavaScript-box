# Ajax - day04

> 今天是Ajax的第`4`天

## 回顾 和 目标:

> 上次重点内容回顾 和 今天的学习目标

### 回顾

1. 原生`ajax`
   1. 不需要掌握代码的写法
   2. 看明白即可

2. `Promise`
   1. 解决了什么问题?
      1. 多个**异步操作,彼此依赖**
      2. 回调函数嵌套--->嵌套的很多--->**地狱**
   2. 嵌套调用变为?
      1. 链式编程`then().then()`
3. 自己抽取`axios`
   1. 用到了什么技术?
      1. 原生`ajax`
      2. `Promise`

4. `axios`和`原生Ajax`和`Promise`的关系?
   1. `axios`请求库
   1. 内部基于原生`Ajax`和`Promise`封装
5. 二级分类
   1. 多个接口要调用




### 目标

1. `Promise`语法补充
2. `eventloop`
   1. 事件循环

3. `Async`异步函数
   1. 用类似于同步代码的方式,写异步
   2. 没有嵌套,没有then

4. 省市区联动

# myAxios

## params解析

> 今天首先把昨天的`myAxios`迭代一下,支持传入`params`

### 需求:

1. 增加`params`的解析
2. `get`请求下,`params`->解析拼接到`url`

```javascript
myAxios({
    url:"",
    method:"",
    data:{},
    params:{
        name:"jack",
        age:18
    }// url?name=jack&age=18
})
```







### 分析:

1. `对象`-->`key=value&key2=value2`
   1. 对象如何取出`key`
      1. `for in`遍历对象,,获取到key
         1. `obj[key]`-->`value`
         2. `[key=value,key2=value2]`
   2. 多个`key=value`如何用`&`拼接到一起
      1. `.join('&')`

2. 什么时候需要转换?
   1. `get`,`params`有值
3. **搞定之后测试一**下!
   1. 英雄查询接口
   2. 聊天机器人接口均测试通过





### params解析

这一节咱们增加了`params`解析的功能,核心是数据格式的转换

1. 本节**循环对象**用的是?
   1. `for in`





# Promise

## Promise-then的返回值

> 为了可以链式调用,咱们会在`then`中返回一个`Promise`对象,如果返回的不是`Promise`对象呢?可以继续点下去码?
>
> [传送门:MDN-Promise.prototype.then](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/then)

### 步骤:

基于官方文档确认如下问题?

1. `then`方法哪来的?
2. `then`方法的返回值是什么类型?
3. `then`方法中返回普通数据.或者不返回内容是否可以继续`.then`?





### 测试代码:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body>
    <script>
      // 1. 自己封装一个返回Promise函数
      function timeoutPro() {
        return new Promise((resolve, reject) => {
          // 执行异步
          setTimeout(() => {
            resolve('延迟1秒执行啦')
          }, 1000)
          // 成功 resolve-->then
        })
      }

      // const back = timeoutPro().then(res => {
      //   console.log(res)
      // })
      // console.log('back:', back)
      /*
        then方法 默认返回的就是Promise对象
        1.无论内部是否写了return
        2.方法的返回值,默认值undefined
        3. then中 把undefined作为Promise的成功结果,给下一个then
        4. 返回了具体的值,作为下一个Promise对象的成功结果
        5. 返回值,不返回的写法用的不多
        6. 常见写法:then中返回 新的Promise对象
      */
      timeoutPro()
        .then(res => {
          console.log(res)
        })
        .then(res2 => {
          console.log('res2:', res2)
          return 998
        })
        .then(res3 => {
          console.log('res3:', res3)
        })
    </script>
  </body>
</html>

```



### Promise-then的返回值

1. `then`方法中如果**不返回**任何内容,是否可以继续`.then`?
   1. 可以
   2. then的返回值默认就是一个`Promise`对象

2. 日常开发中`then`里面如果返回内容,一般返回的是?
   1. 一般会自己返回一个Promise对象,进行链式
   2. 返回一个具体的值,用的不多






## Promise-reject和catch方法

> `new Promise`时传入了2个回调函数`resolve`,`reject`,`reject`并没有过多的处理,今天咱们来看看他
>
> [传送门:MDN-Promise基本示例](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise#%E5%9F%BA%E7%A1%80%E7%A4%BA%E4%BE%8B)
>
> [传送门:MDN-Promise.prototype.then](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/then)
>
> [传送门:MDN-Promise.prototype.catch](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/catch)

### 步骤:

通过给出的传送门**1/2**,确认如下问题:

1. 什么时候触发`reject`方法?
   1. 失败的时候

2. `then`方法中如何添加失败的回调函数?
   1. 可以,第二个

3. `catch`方法从哪来,以及作用是什么?
   1. Promise的原型上
   2. `接收错误的信息`,`失败`的时候会触发








### 测试步骤:

1. 创建一个返回`Promise`对象的函数
2. 延迟`1s`产生`0-100`的随机数
3. `0-50`,`resolve`
4. `51-100`,`reject`进行测试

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body>
    <script>
      // 1. 随机数Promise
      function randomPro() {
        return new Promise((resolve, reject) => {
          // 延迟 1s
          setTimeout(() => {
            // 随机数
            // Math.random() 0-1的小数
            // * 100 控制范围
            // parseInt 转整数
            const num = parseInt(Math.random() * 100)
            if (num > 0 && num < 50) {
              resolve('成功啦:' + num)
            } else if (num >= 50 && num <= 100) {
              reject('失败啦:' + num)
            }
          }, 1000)
        })
      }
      // 1.成功 失败都写了处理逻辑
      // randomPro().then(
      //   res => {
      //     console.log('res:', res)
      //   },
      //   err => {
      //     console.log('err:', err)
      //   }
      // )

      // 2.不考虑失败情况
      // 会有错误提示 uncaught (in promise) 信息
      // randomPro().then(res => {
      //   console.log('res:', res)
      // })

      // 3.catch的写法
      randomPro()
        .then(res => {
          console.log('res:', res)
        })
        .catch(err => {
          console.log('err:', err)
        })
    </script>
  </body>
</html>

```







### Promise-reject和catch方法

1. 什么时候触发`reject`方法?
2. `then`方法中如何添加失败的回调函数?
3. `catch`方法从哪来,以及作用是什么?





## Promise-3种状态及核心示意图

> 实例化`Promise`中的`resolve`和`reject`以及对应的`then`,`catch`咱们已经演示完毕.
>
> 在我们使用`Promise`,它内部还会切换3种不同的状态,咱们来确认一下这几个状态,然后去看看,官方文档中**最为核心示意图**
>
> [传送门:MDN-Promise](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise#%E6%8F%8F%E8%BF%B0)

### 步骤:

1. 结合文档说明,通过打印的方式测试`Promise`的状态是否和文档一致?
2. 基于上一步的测试结果,并阅读官方示意图





![image-20220802102317357](assets/image-20220802102317357.png)





### Promise-3种状态及核心示意图

1. 3种状态分别是?
   1. `pending`:待定,默认
   2. `fulfill`:成功(resolve)
   3. `reject`:失败(reject)
2. 日常开发中自己抽取`Promise`居多,还是使用抽取好的`Promise`居多?
   1. 大部分时候用别人写好的
      1. 调用一个方法-->`Promise`对象

   2. 有一些代码,可能需要自己用Promise包装


## Promise-阶段小结

> 针对目前所学的`Promise`,咱们提炼一下核心内容

**问题:**

谈一谈你对于`Promise`的理解?

1. 第一层理解(**解决了什么问题**)

   1. 回调函数嵌套-->链式编程
   2. `.then().then()`

2. 第二层理解(**语法层面**,**实际应用**)

   1. `new Promise((resolve,reject)=>{  异步的逻辑,  根据成功/失败 (resolve/reject) })`
   2. `resolve`和`reject`的本质,修改`Promise`对象的状态
   3. 状态有3种:
      1. 默认状态:`pending`
      2. 成功:`fullfilled`--->`then`
      3. 失败:`rejected`--->`then`(,失败的回调函数),.`catch`(err=>{})

   4. then方法默认也会返回一个`Promise`,可以继续的`then`下去
   5. 但是一般我们 会自己返回一个`Promise`对象进行处理
   6. 开发中
      1. 常用,接口调用
         1. `then`

      2. 多个接口需要都等待还可以使用`Promise`的静态方法
      3. `Promise.all([pro对象1,promise对象2...]).then(res=>{})`
         1. `res`Promise数组种每一个对象的成功结果

      4. `Promise.race`等待第一个
         1. 语法用过,没有结合具体的业务
         2. 可以请教一下吗?

3. 第三层理解(手写`Promise`)

   1. 自己实现了一个`Promise`
   2. 目前问的不多

   





# eventloop

> 本节演示的代码开发中很少出现,大多出现于**面试题**,主要考察的是对于事件循环的理解





## 热身题

> 首先通过一道简单的题,来找找感觉

### 试题

1. 输出的内容为

```javascript
  console.log(1)
  setTimeout(() => {
    console.log(2)
  }, 2000)
  setTimeout(() => {
    console.log(3)
  },1000)
  console.log(4)
```







### 热身题

本节考察的内容较为简单,当**延迟的时间**有明显的差异时,直接根据**延迟时间**确定结果即可







## 面试题1

> 这一节考察的是同步代码和异步代码,为了更好的分析面试题的执行结果,需要先补充一些预备知识

### 知识补充

1. `JavaScript` 是一门单线程执行的编程语言
2. 为了防止某个耗时任务阻塞，异步代码 由 **js** 委托给**宿主环境**(浏览器)等待执行
3. 满足执行条件的代码会被加入到**任务队列**
4. **主线程空闲**之后,开始执行**任务队列**中的代码
   1. 异步的会等待,主要的代码执行完毕







### 试题

* 当**延迟的时间**有明显的差异时,直接根据**延迟时间**确定结果即可
* `setTimeout`,的延迟时间省略不写默认值为`0`

```javascript
  console.log(1)
  setTimeout(() => {
    console.log(2)
  })
  setTimeout(() => {
    console.log(3)
  })
  console.log(4)
```







### 面试题1

这一节setTimeout的延迟时间为0非常具有迷惑性,记住核心结论

1. 满足执行条件的代码会被加入到**任务队列**
2. **主线程空闲**之后,开始执行**任务队列**中的代码
   1. `setTimeout`无论等待多久,一定要等待主线程执行完毕,在执行
3. 综上`setTimeout(()=>{console.log(1)})`会被加入任务队列











## 面试题2

> 这一节考察的是,对于**异步任务(代码)**的两种不同分类所产生的执行结果

### 知识补充

1. 先执行**主线程代码**
2. 执行本次产生的**微任务**
3. 执行**宏任务**
4. 然后执行该**宏任务**产生的**微任务**
5. 若**微任务**在执行过程中产生了新的**微任务**，则继续执行**微任务**，微任务执行**完毕后**
6. 再回到**宏任务**中进行**下一轮循环**。



### 宏微任务

1. 浏览器端宏任务主要有:

   1. `setTimeout(重点考察)`,`setInterval`....

2. 浏览器端微任务主要有:

   1. `Promise(重点考察)`....

      ```javascript
      new Promise((resolve,reject)=>{
          // 同步
          resolve()
      }).then(res=>{
          // 微任务
      })
      ```

      



### 试题1

* 当**延迟的时间**有明显的差异时,直接根据**延迟时间**确定结果即可

```javascript
  setTimeout(function () {
    console.log(1)
  })
  new Promise(function (resolve, reject) {
    console.log(2)
    resolve(3)
  }).then(function (val) {
    console.log(val)
  })
  console.log(4)
```

### 试题2

```javascript
console.log(1)

  setTimeout(function () {
    console.log(2)
    new Promise(function (resolve) {
      console.log(3)
      resolve()
    }).then(function () {
      console.log(4)
    })
  })

  const p = new Promise((resolve, reject) => {
    console.log(5)
    resolve() // 标记为成功
    console.log(6)
  })

  p.then(data => {
    console.log(7)
  })

  console.log(8)
```



### 面试题2

此类面试题的答题核心就是:

1. 先执行**主线程代码**
2. 执行本次产生的**微任务**
3. 执行**宏任务**
4. 然后执行该**宏任务**产生的**微任务**
5. 若微任务在执行过程中产生了新的微任务，则继续执行微任务，微任务执行完毕后
6. 再回到宏任务中进行**下一轮循环**。

这类面试题中的代码,**开发中基本不会出现**,主要就是作为面试题考察 **eventloop**和**宏微任务**







# async函数

## async函数-基本使用

> `Promise`已经可以很好的解决回调嵌套问题啦,咋又来一个?他的作用是简化`Promise`调用时的写法,把最后一层`then`也给拿掉,让代码写起来就和**同步**一样
>
> [传送门:async函数](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Statements/async_function)

### 步骤:

通过给出的传送门,确认如下问题:

1. `async`函数的作用是什么?
   1. 内部可以用`await`

2. `await`表达式
   1. 等待后面的什么?
      1. `Promise`对象
   2. 返回值是什么?
      1. `Promise`对象的`then`里面的东西
   3. 只能写在什么里面?
      1. `async`函数的内部





### 测试:

1. 分别测试`async/await`的写法?
   1. 自己抽取的`Promise`
   2. ``axios`调用接口



```javascript
// 1.根据传入的时间返回延迟调用的Promise的方法
const delayPro = function(delay){
    return new Promise((reolve,reject)=>{
        setTimeout(()=>{
            resolve(`延迟了 ${delay} 秒`)
        },delay*1000)
    })
}
```



### Async函数-基本使用

1. `async`函数的作用是什么?
2. `await`表达式
   1. 等待后面的什么?
   2. 返回值是什么?
   3. 只能写在什么里面?

## async函数-异常捕获

> `Promise`的链式写法中可以通过`then`的第二个参数或者`catch`来捕获异常,`async`函数写法之后异常的捕获需要通过`try-catch`来完成,咱们来看看如何使用
>
> [传送门:MDN-try-catch](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Statements/try...catch)

### 步骤:

根据文档确认并测试`try-catch`的用法,再结合`async`函数一起使用

1. `try`里面写什么?
   1. 代码
   2. 这部分代码,可能会报错

2. `catch`里面写什么?
   1. try里面如果出现勒异常(错误)
   2. catch中进行处理




### try-catch的用法

```javascript
      // const dog = '秋田!'
      // try {
      //   console.log(dog) // dog 没有定义
      // } catch (error) {
      //   console.log('try里面错啦')
      //   console.log('error:', error)
      // }
      // console.log('底部的代码')
```



### 结合async函数

```javascript
function errorPro() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // reject('失败啦')
        resolve('搞定啦!!!')
      }, 1000)
    })
  }

  // try语法回顾
  /*
    1. 不会阻断代码的后续执行
    2. try中的逻辑错了,代码继续运行(程序更健壮)
    3. try中的逻辑出错,才执行catch
  */
  // const dog = '秋田!'
  // try {
  //   console.log(dog) // dog 没有定义
  // } catch (error) {
  //   console.log('try里面错啦')
  //   console.log('error:', error)
  // }
  // console.log('底部的代码')

  async function func() {
    // await 后面跟的是 Promise对象
    console.log('top')
    // await之后的代码出错啦,直接中断
    try {
      const res = await errorPro()
      console.log('res:', res)
    } catch (error) {
      console.log('error:', error)
    }

    console.log('bottom')
  }
  func()
```





### async函数-异常捕获

1. `try-catch`中?
   1. try里面写?
      1. 可能会出错的代码
      2. 比如`axios`调用接口
   2. catch里面写?
      1. 出错之后要执行的逻辑
2. `async`函数中的异常通过什么捕获?
   1. `try-catch`

3. `try-catch`**只能**和`async`函数一起使用吗?
   1. 任意的js异常都可以用`try-catch`


## async函数-分类列表重构

> 利用刚刚学习的`async`咱们来重写一下分类列表案例

### 需求:

1. 基于实例确认需求:





### 分析:

1. 数据来源于Ajax编程的**商品分类**内部的2个接口?
2. 确认2个接口的数据格式,并分析页面的数据来源?
3. **顶级**导航数据来源?
4. **二级**导航数据来源?







### 代码解析:

```javascript
    <script>
      /*
        1. 获取一级标题
        2. 基于一级标题的id 获取与之对应的二级标题的数据
        3. 所有二级标题的数据拿到之后,渲染
      */
      async function getTitle() {
        // 1. 获取一级标题
        const topRes = await axios({
          url: 'http://ajax-api.itheima.net/api/category/top',
        })
        // console.log('topRes:', topRes)
        // 2.有多少个一级,发送多少个请求二级的
        // 基于数组 map 生成Promise数组 发送9个请求
        const twoPros = topRes.data.data.map(v => {
          return axios({
            url: 'http://ajax-api.itheima.net/api/category/sub',
            params: {
              id: v.id,
            },
          })
        })
        // console.log('twoPros:', twoPros)

        // 3. 所有二级标题的数据拿到之后,渲染
        const twoRes = await Promise.all(twoPros)
        // console.log('twoRes:', twoRes)
        const html = twoRes
          .map(v => {
            return `
            <li>
              <a href="javascript:;">${v.data.data.name}</a>
              <ul class="sub">
               ${v.data.data.children
                 .map(son => {
                   return `<li>
                      <a href="javascript:;">
                        <span>${son.name}</span>
                        <img src="${son.picture}" alt="">
                      </a>
                    </li>`
                 })
                 .join('')}
              </ul>
            </li>
          `
          })
          .join('')
        // console.log('html:', html)
        document.querySelector('.top').innerHTML = html
      }

      window.onload = function () {
        getTitle()
      }
    </script>
```



### async函数-分类列表重构

1. **功能上**和之前的写法是否相同?
2. 代码和之前`Promise`的写法相比有何不同?
3. 如何理解`await`干的事情?



## 上午回顾

> 上午的重点内容

1. `params`解析
   1. `obj`==>`key=value&key2=value2`
2. `Promise`语法补充
   1. then方法的返回值-->`Promise`对象
   2. then方法的第二个参数-->`错误的时候执行的回调函数`
   3. catch方法-->`then方法的第二个参数-`
3. `Promise`的三种状态
   1. pending:默认
   2. fullfilled:成功
   3. rejected:失败
4. `EventLoop`
   1. 异步的代码交给浏览器-
   2. 可以执行之后交给任务队列
   3. 任务队列中有两类
      1. 宏任务
      2. 微任务
   4. 执行顺序
      1. 先执行**主线程代码**
      2. 执行本次产生的**微任务**
      3. 执行**宏任务**
      4. 然后执行该**宏任务**产生的**微任务**
      5. 若**微任务**在执行过程中产生了新的**微任务**，则继续执行**微任务**，微任务执行**完毕后**
      6. 再回到**宏任务**中进行**下一轮循环**。
5. `async`函数
   1. `await`写在`async`修饰的函数中
   2. `await`等待`Promise`对象成功
   3. `try-catch`

## async函数 - 函数的返回值

> 为了让我们更好的组织更为复杂的异步操作,`async`函数的返回值也是处理过的呢
>
> [传送门:async函数的返回值](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Statements/async_function#%E8%BF%94%E5%9B%9E%E5%80%BC)

### 步骤:

1. 根据文档确认`async`函数的返回值?





### 测试:

1. `async`函数的返回值
2. `func1`执行完毕之后再执行 `func2`

```javascript
   function timeOutPro(delay) {
        // 返回Promise对象
        return new Promise(resolve => {
          // 延迟2秒钟 成功
          setTimeout(() => {
            resolve(`延迟了${delay}秒`)
          }, delay*1000)
        })
      }

    async function func1(){
        await timeOutPro(1)
        await timeOutPro(3)
      }
      async  function func2(){
        await timeOutPro(2)
        await timeOutPro(4)
      }
```







### async函数 - 函数的返回值

本节咱们根据文档确认并自己测试了`async`函数的返回值

1. 返回值是什么类型?
   1. `Promise`
2. 基于这一特点,我们如何让多个`async`函数彼此等待?
   1. `await`



# 信息界面

## 信息界面-需求交接

> 首先来确认一下案例的所有功能



## 信息界面-用户信息渲染

> 首先完成用户信息的渲染功能

### 需求:

1. 页面打开获取用户信息
2. 渲染到页面上
   1. **名字**和**头像**
3. 头像:
   1. `img`设置头像地址
   
4. 使用`async`函数





### 分析:

1. **请求:**
   1. 多个接口基础地址一样如何简化?
      1. axios.defaults.baseURL

   2. window.onload

2. **响应:**
   1. 挨个的设置给页面












### 信息界面-用户信息渲染

这一节咱们完成勒用户信息渲染的功能,核心围绕着请求和响应,但是使用了`await`等待接口的响应,那么:

1. `await`需要放在什么里面?

   1. `async function`

   













## 信息界面-省市区渲染

> 接下来渲染省市区数据

### 需求:

1. 根据接口获取 省 市 区数据的选项
2. 根据用户的信息**设置选中项**
3. 使用`async`函数





### 分析:

1. 知识点回顾:
   1. 选中了`option`会将`option`的`value`设置给`select`
   2. 修改`select`标签的`value`属性,会选中对应的`value`的`option`标签
      1. `option`存在
      2. 不存在-->空

2. 获取**省**,设置选中**省**

   1. 接口调用

   2. 保存标签

   3. 生成`option`

   4. 设置选中某个市 `select`标签`value`

3. 获取**市**,设置选中**市**

4. 获取**区**,设置选中**区**















### 信息界面-省市区渲染 代码解析

```javascript
axios.defaults.baseURL = 'http://ajax-api.itheima.net/api'

  async function func() {
    // 1 获取用户信息 并渲染到页面上
    const userRes = await axios({
      url: '/settings',
    })
    console.log('userRes:', userRes)
    // 获取数据 并填充
    const { nickname, avatar, province, city, area } = userRes.data.data
    // 名字
    document.querySelector('[name=nickname]').value = nickname
    // 头像 输入框 img
    document.querySelector('[name=avatar]').value = avatar
    document.querySelector('.figure-img').src = avatar

    // 2.获取 省的信息
    const proRes = await axios({
      url: '/province',
    })
    // 生成options
    const proOpts = proRes.data.data.map(v => {
      return `<option value="${v}">${v}</option>`
    })
    // 渲染选中的省
    const proSel = document.querySelector('[name=province]')
    proSel.innerHTML = proOpts.join('')
    // 设置选中的省
    proSel.value = province

    // 3.获取 省对应的市的信息
    const cityRes = await axios({
      url: '/city',
      params: {
        pname: province, // 把用户当前所在的省传递过去
      },
    })
    // 生成options 渲染到select中 设置选中的项
    const citySel = document.querySelector('[name=city]')
    citySel.innerHTML = cityRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
    citySel.value = city

    // 4.获取 市 对应的区的信息
    const areaRes = await axios({
      url: '/area',
      params: {
        pname: province, // 当前用户所在的省
        cname: city, // 当前用户所在的市
      },
    })
    const areaSel = document.querySelector('[name=area]')
    areaSel.innerHTML = areaRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
    areaSel.value = area
  }
  func()
```

### 信息界面-省市区渲染

这一节是直接根据响应的数据获取并渲染省市区:

1. 为什么**市**需要**等待省**获取之后再去获取?
   1. 不同省的市是不同的
   2. 获取到用户所在的省,才可以去获取市
2. 为什么**区**需要**等待市**获取之后再去获取?
   1. 原因和上面一样





### 注意:

1. 直辖市
   1. 有的城市是直辖市,只有一个
2. 变量命名
   1. 变量命名是所有程序员的痛
   2. 查一下单词
3. 省市区联动
4. 如何修改数据?
   1. `index.html`







## 信息界面-省市区联动

> 接下来咱们完成联动效果

### 需求:

1. 修改**省**的选中值,更新**市**和**区**的内容
2. 修改**市**的选中值,更新**区**的内容
3. 使用`async`函数





### 分析:

1. `select`标签更改选中值会触发哪个事件?
   1. `onchange`

2. 基于接口获取数据,并重新渲染后续`select`的内容
   1. **改变**选中的省:
      1. 获取**市**, **区**
   2. **改变**选中的市:
      1. 获取 **区**











### 信息界面-省市区联动

```javascript
axios.defaults.baseURL = 'http://ajax-api.itheima.net/api'

  async function func() {
    // 1 获取用户信息 并渲染到页面上
    const userRes = await axios({
      url: '/settings',
    })
    console.log('userRes:', userRes)
    // 获取数据 并填充
    const { nickname, avatar, province, city, area } = userRes.data.data
    // 名字
    document.querySelector('[name=nickname]').value = nickname
    // 头像 输入框 img
    document.querySelector('[name=avatar]').value = avatar
    document.querySelector('.figure-img').src = avatar

    // 2.获取 省的信息
    const proRes = await axios({
      url: '/province',
    })
    // 生成options
    const proOpts = proRes.data.data.map(v => {
      return `<option value="${v}">${v}</option>`
    })
    // 渲染选中的省
    const proSel = document.querySelector('[name=province]')
    proSel.innerHTML = proOpts.join('')
    // 设置选中的省
    proSel.value = province

    // 3.获取 省对应的市的信息
    const cityRes = await axios({
      url: '/city',
      params: {
        pname: province, // 把用户当前所在的省传递过去
      },
    })
    // 生成options 渲染到select中 设置选中的项
    const citySel = document.querySelector('[name=city]')
    citySel.innerHTML = cityRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
    citySel.value = city

    // 4.获取 市 对应的区的信息
    const areaRes = await axios({
      url: '/area',
      params: {
        pname: province, // 当前用户所在的省
        cname: city, // 当前用户所在的市
      },
    })
    const areaSel = document.querySelector('[name=area]')
    areaSel.innerHTML = areaRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
    areaSel.value = area

    // 5. 省的联动效果 change 市区改变
    proSel.onchange = async function () {
      // console.log('重新选择省')
      // 基于当前的省 获取 市
      const cityRes = await axios({
        url: '/city',
        params: {
          pname: this.value, // 当前选择的省传递过去
        },
      })
      // 生成 option 并设置给 城市的select标签
      citySel.innerHTML = cityRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
      // 基于当前的市 获取 区
      const areaRes = await axios({
        url: '/area',
        params: {
          pname: this.value, // 当前用户选择的省
          cname: citySel.value, // 当前选择的城市信息
        },
      })
      // 获取到的区数据,生成option 设置给 区域的选择框 ,默认选中 第一个
      areaSel.innerHTML = areaRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
    }

    // 6. 市的联动效果 change 区改变
    citySel.onchange = async function () {
      // console.log(this.value)
      // 基于当前的省市 获取对应的 区
      // 基于当前的市 获取 区
      const areaRes = await axios({
        url: '/area',
        params: {
          pname: proSel.value, // 获取省的select并获取value
          cname: this.value, // 当前选择的城市信息
        },
      })
      // 获取到的区数据,生成option 设置给 区域的选择框 ,默认选中 第一个
      areaSel.innerHTML = areaRes.data.data.map(v => `<option value="${v}">${v}</option>`).join('')
    }
  }
  func()
```



### 省市区联动

1. **onchange**
   1. 重新获取数据+渲染









# 总结 和 作业

> 重点内容总结 和 作业

### 总结

1. 



### 作业

商城:
1. 其他资料
2. ![image-20220802171403417](assets/image-20220802171403417.png)





