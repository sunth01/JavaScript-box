# Ajax - day03

> 今天是`Ajax`的第`3`天



## 回顾和目标

> 内容回顾 和 学习目标

### 回顾

1. `axios`的`config`模式:

   1. ```javascript
      axios({
          url:"",// 请求地址
          method:"",// 请求的方法
          data:{},// 请求的数据(请求体中)
          params:{} // 请求的数据(get,URL中) url?key=value&key2=value2
      })
      ```

2. `form`表单数据提交

   1. 默认`form`提交的缺点? 刷新页面
   2. `ajax`提交`form`表单需要阻止的默认行为?
      1. `form`的`onsubmit`
      2. `button`的`onclick`
      3. 任意选一个
      4. `e.preventDefault()`
   3. 可以通过`form-serialize`插件简化什么?
      1. 表单数据取值
      2. `FormData`:可以上传文件
      3. `form-serialize`只是获取数据-->不包含文件,用户输入的内容

3. `ajax`文件上传

   1. 用到了哪个对象?
      1. `FormData`
   2. 如何添加数据?
      1. `append(key,value)`
         1. `e.target.files[0]`
         2. `dom.files[0]`
   3. 如何获取`input type=file`选中的文件?

4. 图书管理

   1. 列表渲染
   2. 新增
      1. bootstrap--Modal
      2. `const modal= new bootstrap.Modal(弹框的dom元素)`
      3. `modal.show() 显示`
      4. `modal.hide() 隐藏`
   3. 删除
      1. 点击不同行,删除的元素是不同的
      2. 每一行都需要绑定点击事件,保存`id`
         1. `data-id`保存,dom元素上,html结构中
         2. `dataset.id`获取,JavaScript中写的
         3. 事件绑定-->事件委托
   4. 保存修改
      1. 每一行都需要绑定点击事件,保存`id`
         1. `data-id`保存,dom元素上,html结构中
         2. `dataset.id`获取,JavaScript中写的
         3. 事件绑定-->事件委托
      2. 进入修改状态
         1. 根据`id`获取数据
      3. 保存修改
         1. 传,把最新的数据提交给服务器





### 目标:

1. 原生ajax(**了解**)
2. Promise
3. Promise+原生ajax抽取axios
4. Promise的静态方法



# 原生Ajax

## 原生ajax-基本使用

> `axios`是基于原生`ajax`封装的,简单易用,但是为了更好的理解他内部做的事情,咱们来认识一下**原生的写法**
>
> [传送门:mdn-ajax](https://developer.mozilla.org/zh-CN/docs/Glossary/AJAX)



### 使用步骤:

1. **代码不用背**,理解意思即可
2. 实例化 `XMLHttpRequest` 异步对象(**内置**)
3. 设置请求 **地址** 和 **方法** 
4. 注册**回调函数**
5. 发送请求

```javascript
  // 1.实例化异步对象
  const xhr = new XMLHttpRequest()
  // 2.设置请求的 地址 和方法
  xhr.open('请求方法','请求地址')
  // 3.注册回调函数 服务器响应内容回来之后触发
  xhr.addEventListener('load',function(){
	console.log(xhr.response)
  })
  // 4.发送请求
  xhr.send()
```



### 小测试:

1. 基于**新闻接口**调整代码进行测试

4. 确认两件事:

   1. 是否**发送请求**?
      1. 发了请求

   2. 页面是否**重新加载**?
      1. 没有
   
   
   
   





### 交互流程

1. 









### 原生ajax-基本用法

这一节咱们演示了原生的Ajax如何使用,代码不用背下来,但是要理解每一段的作用哦.如下代码每一行的意思是?

```javascript
// 1. 创建 小黄人对象
const xhr = new XMLHttpRequest()
// 2. 设置 请求的方法和路径(地址)
  xhr.open('请求方法','请求地址')
// 3. 准备接收数据
  xhr.addEventListener('load',function(){
	console.log(xhr.response)
  })
// 4. 发送请求
  xhr.send()
```





## 原生ajax-get请求传参

> 上一节的请求中并没有携带参数,这一节咱们来演示一下如何通过`get`请求传递参数,传递**查询字符串(querystring)**

### 格式:

1. 在`url`的末尾按照格式拼接参数即可
2. `url地址?key1=value1&key2=value2`





### 小测试:

基于**聊天机器人接口**进行测试

确认如下问题:

1. 是否成功将**参数**提交到了服务器?
   1. 有的






### 原生ajax-get请求传参 

这一节演示如何通过get请求传递参数(**querystring**),位置和格式都有要求:

1. 参数传递的位置?

   1. url中

2. 参数传递的格式?

   1. `url?key=value`
   2. **查询字符串**--->`querystring`

   

   





## 原生ajax-post请求传参urlencoded

> 不同于上一节`get`请求传递参数,`post`传递参数需要设置的内容会多一些

### 步骤:

1. `open()`方法之后通过`xhr.setRequestHeader(key,value)`的形式设置数据格式
   1. `setRequestHeader`设置请求头
   1. `set`  设置
   1. `Request`请求
   1. `Header` 头
2. `send()`方法中传递具体的数据,**需要和格式一致**
   1. `send`中的内容会在**请求体**中







### 小测试:

1. `xhr.setRequestHeader(key,value)`设置的请求头在**请求报文**中是否可以看到?
   
2. 随意设置的请求头是否有意义?





### 调整content-type

通过**测试表单提交**接口进行测试

- **测试:**
  - 根据接口文档要求通过`setRequestHeader`设置`content-type`请求头
  - 通过`send`方法提交**符合格式**要求的数据,并**确认结果**









### 原生ajax-post请求传参

这一节演示了如何通过原生的ajax结合post提交数据,通过**请求体**传递数据

1. `setRequestHeader()`方法的作用是?

   1. 设置请求头 

2. `setRequestHeader('content-type', 'application/x-www-form-urlencoded')`设置之后,**send**中数据需要是什么格式?

   1. `key=value&key2=value2`

   




## 原生ajax-post请求传参json

> 上一节测试了`application/x-www-form-urlencoded`这种格式的数据,对于`application/json`格式的数据呢?
>
> [传送门:JSON](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/JSON)

### 步骤:

1. `open()`方法之后通过`xhr.setRequestHeader(key,value)`的形式设置数据格式
   1. `setRequestHeader`设置请求头
2. `send()`方法中传递具体的**数据**,**需要和格式一致**





### JSON回顾

**JSON** 是一种语法，用来序列化对象、数组、数值、字符串、布尔值和 [`null`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Operators/null) 。如下几个是否为`JSON`

```javascript
const data1 = { name: 'jack', age: 18 }// 不是 js对象
const data2 = '{"name":"jack","age":18}'// 是 字符串 属性名需要加引号
const data3 = ['西瓜', '西兰花']// 不是 js的数组
const data4 = '["西瓜","西兰花"]'// 是 字符串
```

开发中偶尔需要将**JSON**和**对象/数组**互转,会用到2个方法他们是?

1. `{ name: 'jack', age: 18 }`--->`'{"name":"jack","age":18}'`?
   1. **序列化**  JSON.stringify()
2. `{"name":"jack","age":18}`--->`{ name: 'jack', age: 18 }`?
   1. **反序列化**:JSON.parse()







### 测试接口

通过 **登录-表单提交**接口进行测试

- **测试:**
  - 根据接口文档要求通过`setRequestHeader`设置`content-type`请求头
  - 通过`send`方法提交**符合格式**要求的数据,并**确认结果**(可以通过**JSON.stringify**转化格式)











### 原生ajax-post请求传参json

1. `{name:"jack",age:18}`是不是`JSON`?

   1. 不是
   2. 属性名没有**引号**

2. `setRequestHeader('content-type', 'application/json')`设置之后,**send**中提交数据的格式为?

   1. JSON
   2. `{"username":"admin"}`
   3. `JSON.stringify()`

   


## 原生ajax-解析响应数据

> 上几节咱们只考虑**提交**数据,并没有**解析**服务器响应的数据,这一节咱们来解析一下

![image-20220709010641403](assets/image-20220709010641403.png)

`ajax`和服务器交互的数据格式:

1. `XML`,早期,现在基本不用

   1. 都是双标签
   2. 标签名可以自定义
   3. 必须有一个根标签

   ```xml
   <object>
   	<username>jack</username>
       <password>123456</password>
   </object>
   ```
2. `JSON`,目前**主流**





### 思考

1. 观察`响应头`中的`content-type`
   1. 目前大部分请求的响应格式为`JSON`

2. 观察`响应体`中的**数据格式**
   1. 确实是`JSON`

3. 如何解析?
   1. `JSON.parse`










### 原生ajax-解析响应数据

这一节咱们学习了如何解析响应数据的格式,从确认到解析有如下几个关键的点:

1. 如何确认**响应数据**的格式?
   1. 响应头中的`content-type`

   2. 内容的格式

2. 目前**主流**的交互格式是?
   1. `JSON`

3. 如何解析**主流**格式的数据?
   1. `JSON.parse()`
   2. `JSON.stringify()`





# Promise

## Promise-同步概念

> 为了更好的理解`Promise`的作用,咱们需要先**同步2个概念**,**异步函数**和**回调函数**,以及多个**回调函数嵌套**带来的问题
>
> [传送门:异步的JavaScript](https://developer.mozilla.org/zh-CN/docs/Learn/JavaScript/Asynchronous)

### 异步函数

1. **异步函数**的执行，由于是异步的，不会阻塞**主线程代码**的执行
2. 常见异步函数(触发时机分别是?)
   1. `setTimeout`
   2. `setInterval`
   3. 原生`ajax`
   4. ....



### 回调函数

1. 把一个**函数当成参数**传递, **将来**特定的时机**调用**, 这个函数就叫**回调函数**。
   1. 把函数当作参数传递,被传递的那个函数--->**回调函数**


![image-20220709014935527](assets/image-20220709014935527.png)

2. 指出下列代码中是否使用了**回调函数**,如果**是**,那么哪个是**回调函数**?

```javascript
setInterval(
    function(){
    console.log('123')
		}
    ,1000)
xhr.addEventListener('load',
                     function(){
	console.log(xhr.response)
	}
                    )
```

3. 大部分有**回调函数**的地方,都会涉及到**异步函数**

### 回调函数嵌套

多个异步操作**彼此依赖**,所产生的**嵌套代码**

如果嵌套的很多,很多也可以称之为:**回调地狱**

**比如:**

1. 1秒之后打印1
2. 1打印之后,等待2秒打印2
3. 2打印之后,等待3秒打印3
4. .....(写出来看看)

```javascript
      setTimeout(() => {
        console.log(1)
        setTimeout(() => {
          console.log(2)
          setTimeout(() => {
            console.log(3)
          }, 3000)
        }, 2000)
      }, 1000)
```



### Promise-同步概念

这一节咱们介绍了一些概念,目的是更好的理解`Promise`的作用,重点如下

1. 常见的**异步函数**有?

   1. `setTimeout`

   2. `setInterval`

   3. `原生ajax`

2. **回调函数**指的是?

   1. 把函数作为参数传递

   2. 被传递的那个函数,叫做回调函数

   3. 一般有回调函数的地方,都有异步

3. 什么时候会出现**回调函数嵌套**的情况?

   1. 多个异步操作**彼此依赖**,所产生的**嵌套代码**
   2. 嵌套的足够多-->**回调地狱**
      1. 问你:你嵌套多少层? 18层
      2. 你什么情况下嵌套18层?









## Promise-概念及基本使用

> `Promise`可以用来解决上一节**回调函数嵌套**的问题,咱们来看看如何**使用它**
>
> [传送门:mdn-Promise](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise)

### 概念

1. [`Promise`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise) 是一个对象，它代表了一个**异步操作**的最终完成或者失败。
2. `axios`就是基于`Promise`封装的
3. 基于**Promise**之后的约定:
   1. 通过`then`获取成功结果
   2. 通过`catch`获取失败结果
   3. 可以用**链式的方式**处理多个彼此依赖的异步操作
      1. 一路点下去
      2. `arr.map().filter().map().filter()`
      3. 上一个方法的返回值,可以继续点出后续的方法
4. 大部分异步函数最新的`api`都有`Promise`的版本,有一些可能需要自己封装,比如(**setTimeout**)



### 小测试

1. 通过`axios`发送请求之后返回的是不是`Promise`对象?
2. 确认是否有`then`和`catch`方法?





### 使用步骤

```javascript
// 1. 创建 并传入回调函数
const p = new Promise((resolve,reject)=>{
    // 内部一般封装异步的操作
    // 成功执行 resolve
    // 失败执行 reject
})
// 2. 使用
p.then(res=>{}) // resolve的值
.catch(err=>{}) // reject的值
```





### 代码解析:

```javascript
 // 原生Promise的写法
      // const p = new Promise(function (resolve, reject) {})
      // new Promise时传入的回调函数中的 2个参数
      //  resolve reject
      // Promise会传入2个具体的函数进来
      // 内部根据异步执行的结果 触发对应的函数 即可 -->成功/失败
      //  resolve   reject (形参) 名字可以改,但是建议别改
      const p = new Promise((resolve, reject) => {
        console.log('resolve:', resolve)
        console.log('reject:', reject)
        // 写异步的代码
        // 根据成功  resolve then
        setTimeout(() => {
          // resolve('成功 ')
          reject('哎呀,失败')
        }, 1000)
        // 根据失败 reject catch
      })

      // console.log('p:', p)
      p.then(res => {
        console.log('res:', res)
      }).catch(err => {
        console.log('err:', err)
      })
```







### Promise-概念及基本使用

这一节介绍了`Promise`的概念和如何自己创建`Promise`对象,在继续推进后续代码前,先明确这几个概念

1. 日常开发中大部分的`Promise`是自己封装,还是有现成的?
   1. 大部分都有现成
2. 内部调用`resolve`,`reject`对应到Promise对象的哪个方法?
   1. `resolve`-->`then`
   2. `reject`--->`catch`







## Promise-链式调用

> 使用学习的`Promise`来解决多个异步操作**彼此依赖**,所产生的**回调函数嵌套**的问题,将**嵌套**,变为**链式**

### 需求:

1. 使用`Promise`结合`setTimeout`
2. 延迟1秒,打印1
3. 打印1之后,延迟2秒,打印2
4. 打印2之后,延迟3秒,打印3
5. .....





### 语法补充:

1. `then`方法内部返回`Promise`对象
2. `Promise`对象可以`.then`
3. 最终形成`.then().then().....`这种链式结构





### 步骤:

1. 基于上一步的测试结果,使用`Promise`结合`setTimeout`完成完成需求







### 代码解析:









### Promise-链式调用

这一节咱们通过Promise来组织多个**彼此依赖**的异步操作,没有嵌套,变成了**链式**:

1. `promise`对象的`then`方法中如果返回了`Promise`对象,可以在后面继续`.`什么?`then`

   1. `Promsie`对象原型上`then`

2. 目前的代码写法

   1. 是否实现了本节的需求?
      1. 实现了-->链式

   2. 本节代码的写法是否冗余?
      1. 不太好看,优点冗余




## Promise-抽取

> 上一节的链式调用中有大量重复的**创建Promise对象**的语法,为了简化调用,咱们抽取一下

### 需求:

1. 抽取一个方法,调用返回`Promise`对象
2. 接收延迟的**时间**,到时之后`then`中可以获取到`延迟了 xx 秒执行`

```javascript
function timeoutPro(delay) {
    return new Promise((resolve, reject) => {
      // 代码略
    })
}

// 运行效果
timeoutPro(2)
.then(res => {
  console.log(res) // 延迟了2秒执行
  return timeoutPro(3)
})
.then(res => {
  console.log(res) // 延迟了3秒执行
})
```





### 分析:

1. 延迟执行代码使用`setTimeout`
2. `setTimeout`设置延迟单位是?
3. 内部执行哪个方法,对应到外部的`then`
4. `then`中如何获取到数据?





### Promise-抽取

这一节咱们学习了如何将创建`Promise`对象的逻辑提取为方法,到目前为止演示的都是**Promise**的语法,并没有业务,重点是:

1. 抽取**方法**,返回`Promise`对象
2. 不确定的部分作为**方法的参数**
   1. 定义的时候-->形参
   2. 调用的时候-->实参
3. 使用时直接调用抽取的方法即可
   1. `timeoutPro()`
   2. `axios()`







## 上午回顾

> 上午的重点内容

1. 原生Ajax(了解)

   ![image-20220801143527683](assets/image-20220801143527683.png)

2. `Promise`

   1. 多个**异步彼此依赖**
      1. 3等2等1
   2. 回调函数 **嵌套**
   3. 让我们可以用更好的方式来组织异步
      1. then:成功
      2. catch:失败
   4. `.then().then().then()`....
   5. 返回`Promise对象`
   6. `function timeoutPro(){}`
   7. `axios()--->Promise对象`











# 简化版axios

## 简化版axios-固定请求地址和方法

> 咱们一步一步的把`Promise`和今天学过原生`Ajax`结合起来,先来实现一个最简单的版本
>
> **注:**功能并不完备,目的是帮助大伙理解内部的逻辑

### 需求:

1. 调用`myAxios`方法
2. `.then`中即可获取新闻
3. 服务器响应的内容**直接返回**,不转换格式

```javascript
  function myAxios() {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('', '')
      xhr.addEventListener('load', function () {
        console.log(xhr.response)
      })
      xhr.send()
    })
  }
  myAxios().then(res => {
    console.log('res:', res)
  })
```



### 分析:

1. 目前直接把`url`和`method`写死
2. `then(res=>{})`对应到内部的`resolve(xxx)`



### 代码解析:







### 简化版axios-固定请求地址和方法

这一节咱们实现了最基本的功能,可以发请求啦,也不再是**回调函数嵌套**啦:

1. 现在的写法从**回调函数嵌套**,转变为了什么?
   1. 链式编程-->`.then`

2. 请求地址和请求方法**写死**在方法内部咋样?
   1. 功能可以搞定
   2. 不灵活




## 简化版axios-参数提取

> 接下来把上一节代码中写死的内容提取出来

### 需求:

1. 调用`myAxios`方法
2. 用对象的格式
   1. 目前只考虑`get`请求
   2. 参数只能拼接在`url`后面(如果有的话)

```javascript
  function myAxios(options) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('', '')
      xhr.addEventListener('load', function () {
        console.log(xhr.response)
      })
      xhr.send()
    })
  }
  myAxios({
    method:"get",
    url:"地址+参数"
  }).then(res => {
    console.log('res:', res) // 10条笑话
  })
```

### 分析:

1. 传入的`options`是什么类型?
   1. 对象
      1. url
      2. method

2. 将代码中写死的内容,替换为传入的值即可





### 代码解析:





### 简化版axios-参数提取

这一节将代码中一些固定的内容提取出来作为**参数**:

1. 参数**使用对象**的优点?
   1. 可以更方便的传入多个参数
   2. 属性名只要没问题即可
   3. 如果用多个参数,
      1. 参数的顺序,固定的不能调整



## 简化版axios-JSON传递

> 最后把`send`中可以提交`JSON`的功能也整合进来

### 需求

1. 传递的数据通过`data`属性,以**对象**形式传入
2. 提交给服务器的格式为`JSON`

```javascript
  function myAxios(options) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('', '')
      xhr.addEventListener('load', function () {
        console.log(xhr.response)
      })
      xhr.send()
    })
  }
myAxios({
    url:"完整url地址包含参数",// 完整地址
    method:"get",// 小写的请求方法  get/post/put/delete
    // data get提交不用设置
}).then(res=>{
    res // JSON.parse转化完毕的数据
})
myAxios({
    url:"完整url地址",// 完整地址
    method:"post",// 小写的请求方法 get/post/put/delete
    data:{} // post/put都可以通过data传递数据
}).then(res=>{
    res // JSON.parse转化完毕的数据
})
```



### 分析

1. `get/post/delete/put`都是请求方法,设置的位置是否相同?
   1. open的第一个
   2. 代码不需要调整

2. `JS`对象如何转`JSON`?
   1. `JSON.stingify(对象)-->JSON`

3. 如何设置提交的数据格式(**json**)?
   1. `xhr.setRequestHeader('content-type','application/json')` 设置 请求头
   2. `xhr.send(JSON)`







### 测试

1. 实现之后可以结合如下接口进行测试
2. **用户登录接口**
3. **图书新增接口**
4. **图书删除接口**
5. **图书修改接口**





### 代码解析





### 简化版axios-JSON传递

这一节咱们实现了传递`JSON`,功能和用法上已经和`axios`很类似啦:

1. `myAxios`的抽取并没有实现`axios`的所有功能,只实现了:
   1. `myAxios()--->Promise对象`(then)
   2. url:
      1. 普通的url
      2. 拼接了`querystring`,`url?key=value`
      3. `url/990`
   3. method:
      1. `get/post/put/delete`
      2. 省略是`get`
   4. data:
      1. 对象-内部会转为-JSON
2. 开发中发请求用`axios`还是本节自己抽取的?
   1. `axios`
3. 自己抽取简化版`axios`的目的是?
   1. 理解内部执行的逻辑
4. 什么情况下会自己封装**库**?
   1. **初期:**
      1. 使用别人写好的库
   2. **中期:**
      1. 逐步的看别人写的源码,理解内部的逻辑
      2. 发现一些不好的地方-->告诉库的**开发者(开发团队)**
      3. 可能会被采纳--->帮助**开源框架(库)的进步**
   3. **再进一步:**
      1. 发现一些不好的地方,自己也会改
      2. 改好之后提交给--->**开发者(开发团队)**
      3. 被**开发者(开发团队)**采用
      4. **开源框架(库)的贡献者**
   4. **高阶:**
      1. 目前市面上没有满足自己的库,框架
      2. 自己写一个,传到开源社区
      3. 很多人点赞-->开心-->继续迭代-->更多人点赞-->(循环)
      4. **开源框架(库)的开发者**





# Promise的静态方法

## Promise-all和race方法

> 除了`实例化`对象使用的`then/catch`以外,`Promise`还提供了可以管理多个异步的方法哦,咱们先来看看其中使用频率较高的2个`all`和`race`
>
> [传送门:Promise.all](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/all)
>
> [传送门:Promise.race](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/all)

### 步骤:

1. 基于文档确认用法并回答如下问题
2. `Promise`只提供了`all`和`race`方法码?
   1. 不是,还有一些其他

3. 隐藏知识点:
   1. `函数`也是**对象**
   2. 函数也可以点东西出来
   3. `Promise.all()`
4. 结合文档确认`Promise.all`和`Promise.race`方法的作用并测试?
   1. **静态方法**,
   2. `Promise.all`
   3. `Promise.race`



### 测试:

1. 基于**提供的方法**进行测试
2. 分别测试`Promise.all`和`Promise.race`的区别

```javascript
// 1.根据传入的时间返回延迟调用的Promise的方法
const delayPro = function(delay){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve(`延迟了 ${delay} 秒`)
        },delay*1000)
    })
}
```



### Promise-all和race方法

1. `Promise.all`方法的作用是?适用场景?
   1. 页面中的数据,来源于多个接口
   2. 需要等待多个接口都获取到结果之后才可以渲染
   3. `Promise.all([接口1,接口2,接口3...]).then()`

2. `Promise.race`方法的作用是?适用场景?
   1. 某个功能,需要调用接口
   2. 多个服务器都有这个接口,考虑到网速,服务器稳定性的问题
      1. 接口A和接口B功能一样
      2. 保证有一个成功即可

   3. `Promise.race([接口1,接口2]).then()`






## demo-分类列表

> 结合刚刚学习的内容,咱们来完成**分类列表**渲染案例
>
> [传送门:接口汇总](https://www.apifox.cn/apidoc/shared-fa9274ac-362e-4905-806b-6135df6aa90e/doc-842135)

### 需求:

![image-20220801083913228](assets/image-20220801083913228.png)

1. 基于实例确认需求:
   1. 基于提供的数据接口渲染页面的导航





### 分析:

1. 数据来源于Ajax编程的**商品分类**内部的2个接口?
   1. 顶级分类
   2. 二级分类

2. 确认2个接口的数据格式,并分析页面的数据来源?
   1. 顶级包含所有
   2. 二级需要传入顶级的id才可以获取
   3. 有9个二级--->发送9个二级请求

3. **顶级**导航数据来源?
4. **二级**导航数据来源?
5. 多个接口都成功
   1. Promise.all()







### 代码解析:





### demo-分类列表

这一节咱们完成了分类列表的案例,核心点是如何使用**Promise.all**来管理多个Promise对象:

1. 本节页面中的导航数据是否来源于**多个**接口?
   1. 多个
      1. 顶级
      2. 二级

2. 如何等待多个`Promise`对象完成?
   1. `Promise.all()`-->`arr`-->`map.join`








# 总结 和 作业

> 今天的**重点**内容

### 总结:



### 作业:

1. 自己抽取的myAxios
   1. **Promise+ajax**

2. 二级分类












