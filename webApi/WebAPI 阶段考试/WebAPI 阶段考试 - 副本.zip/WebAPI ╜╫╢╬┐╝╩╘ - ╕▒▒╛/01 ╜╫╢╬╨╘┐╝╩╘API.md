### 姓名	： 

### 分数	：

---

希望大家做选择和简答题部分时，不要把代码放在VSCode或浏览器上运行得出答案，全靠自觉哈~ 考试分数不重要，重点是掌握知识点，查漏补缺。

！！ 注意，同学们记得边做边保存文件！！ Ctrl + S 保存！！

代码题在文件夹中有对应的html文件哈！



## 一、单选题（共30题，总分60分）

##### 1. 关于DOM中获取元素的方法，下列说法正确的是？   （ ） B

A: 	document.querySelector('.box') 是获取页面所有的元素

B: 	document.querySelector('.box') 是获取页面第一个类名为box的元素

C: 	document.querySelectorAll('.box') 是获取页面最后一个类名为box的元素

D: 	document.querySelector('.box') 是获取页面所有类名为box的元素



##### 2. 关于js中的事件，下列说法错误的是？ (   )  A

A:	元素不能注册同名事件,比如给同一个按钮同时注册2个点击事件

B:	事件注册之后，比如点击，鼠标经过等事件，不会立即触发

C:	页面中DOM元素是都可以注册事件的

D:	事件既可以通过用户交互来触发，也可以使用代码主动触发,比如 btn.click()



##### 3. 关于innerText与innerHTML下列说法正确的是？ ( 	)  D

A:	innerText与innerHTML作用完全一致，没有任何区别

B:	innerText属性里设置的标签可以被解析

C:	innerText获取内容的时候，如果内容中有HTML标签，标签会被正常解析

D:	innerHTML获取内容得到的是一个包含HTML标签的字符串



##### 4. 关于window对象，下列说法错误的是?    	（ 	） D

A:	window对象是浏览器里的顶级对象

B:	window对象的属性和方法在调用时，可以省略window

C:	console.log(window.document === document) 这行代码会打印true

D:	window对象的load事件会在页面DOM树加载完毕后立马执行



##### 5.  下列选项关于事件委托说法错误的是？ B

A: 事件委托可以解决事件绑定程序过多的问题

B: 事件委托利用了事件捕获原理

C: 事件委托可以提高代码性能

D: 事件委托可以应用在click, mousemove等事件中



##### 6. 下面代码输出什么   C

```js
for (var i = 0; i < 3; i++) {
    setTimeout(function () {
        console.log(i);
    }, 1);
}
for (let i = 0; i < 3; i++) {
    setTimeout(function () {
        console.log(i);
    }, 1);
}
```

A:  0 1 2             0 1 2

B:  0 1 2             3 3 3

C:  3 3 3             0 1 2

C:  3 3 3             3 3 3



##### 7. 下面代码输出什么？ A 

```js
let c = { greeting: "Hey!" };
let d = c;
c.greeting = "Hello";
console.log(d.greeting);
```

- A: `Hello`
- B: `undefined`
- C: `ReferenceError`
- D: `TypeError`



##### 8. cool_secret可以访问多长时间?   B

```js
sessionStorage.setItem("cool_secret", 123);
```

- A：永远，数据不会丢失。
- B：用户关闭选项卡时。 (页面)
- C：当用户关闭整个浏览器时，不仅是选项卡。
- D：用户关闭计算机时。



##### 9.  下面输出正确的是  C
```js
console.log('开始执行');
setTimeout(function(){
  console.log('timeout1')
},0);
console.log("结束了")
```

- A：开始执行，timeout1，结束了
- B：timeout1，开始执行，结束了
- C：开始执行，结束了，timeout1
- D:  以上都不对



##### 10. 下面打印name值是多少   A
```js
var name = "jimmy";
var a = {
    name: "chimmy",
    fn : function () {
        console.log(a.name); 
    }
}
console.log(window.name) 
a.fn(); 
```

A:  jimmy    	chimmy

B:  jimmy 		jimmy

C: chimmy		jimmy

D: chimmy		chimmy		



##### 11. 下边这代码输出的结果是：（  ） D

```js
function showCase(value) {
    switch(value) {
    case 'A':
        console.log('Case A');
        break;
    case 'B':
        console.log('Case B');
        break;
    case undefined:
        console.log('undefined');
        break;
    default:
        console.log('Do not know!');
    }
}
showCase(new String('A'));    
// 1. new String('A')  ==> 对象
// 2. switch 里面的case 匹配是  全等  ===      值和类型都必须相等  
```
A、Case A

B、Case B

C、undefined

D、Do not know!




##### 12. 下面代码输出什么？（ 	）  C

```js
const numbers = [1, 2, 3];
numbers[10] = 11;
console.log(numbers);
```

A: [1, 2, 3, 7 x null, 11]

B: [1, 2, 3, 11]

C: [1, 2, 3, 7 x empty, 11]

D: SyntaxError



##### 13. 下边代码输出的结果是  （ 	 ）  A

```js
var name = 'World!';
(function () {
    // function 函数作用域
    var name ;
    // 声明的变量不赋值，默认就是undefined
    if (typeof name === 'undefined') {
        name = 'Jack';
        console.log('Goodbye ' + name);
    } else {
        console.log('Hello ' + name);
    }
})(); 

// 1. if 是一个语句， 不能形成作用域的（var）

// 1. JS代码的执行过程， 先预解析的过程。 一开始回去看代码里面var声明的变量和function声明的函数，都会提升到当前作用域最顶层

```

A: Goodbye Jack

B: Hello Jack

C: Hello undefined

D: Hello World



##### 14. 以下js操作Array的方法中不能添加元素的是：（	B   ）

A、push

B、pop

C、unshift

D、splice



##### 15. var arr = [];   typeof arr 的结果是(    )   C

A、array

B、function

C、object

D、undefined

```js
typeof arr ==> 'Object' 
typeof null ==> 'Object'
```





##### 16. 以下代码执行后，console 的输出是    A

```js
function Foo(){
	console.log(this.location);
}
Foo();
```

A、当前窗口的 Location 对象

B、undefined

C、null

D、TypeError



##### 17. 事件传播的三个阶段是什么 ？  D

A:	目标 -->  捕获  -->  冒泡

B:	冒泡  --> 目标 -->   捕获

C:    目标  --> 冒泡  -->  捕获

D:    捕获  --> 目标  -->  冒泡



##### 18. 下列事件哪个不是由鼠标触发的事件？  D

A、click

B、contextmenu

C、mouseout

D、keydown



##### 19. 下面数组的方法中，哪个方法不能改变自身数组    B

A、splice

B、concat

C、sort   // 排序

D、pop



##### 20. 要在10秒后调用checkState，下列哪个是正确的    C

A、window.setTimeout(checkState, 10);

B、window.setTimeout(checkState(), 10);

C、window.setTimeout(checkState, 10000);

D、window.setTimeout(checkState(), 10000);



##### 21.以下不支持冒泡的鼠标事件为( )   C

A. mouseover 

B. click 

C. mouseleave 

D. mousemove



##### 22. 在javascript中，用于阻止默认事件的默认行为的方法是   C

A. **stopDeafault**() 

B. **stopPropagation**() 

C. **preventDefault**() 

D. **preventDefaultEven**()



##### 23. DOM中，给父节点添加子节点的正确方法为    D

A. **appendChild**(parentNode,newNode); 

B. **append**(parentNode,newNode); 

C. parentNode.**append**(newNode); 

D. parentNode.**appendChild**(newNode);



##### 24. **下列定义的 css 中，哪个权重是最低的？**   C

```js
!important    10000 
行内样式 style="color:red"  1000 
# id    100
. 类名   10
标签     1 
```



A、#game .name

B、#game .name span

C、#game div

D、#game div.name



##### 25. Chrome浏览器中，获取鼠标单击页面位置的是（）。  B

A. clientX和clientY 

B. pageX和pageY

C. screenX和screenY

D. scrollLeft和scrollTop



##### 26. 正则表达式`/[am][efgr]/ig`匹配字符串“programmer”的结果是（）。D

A. am

B. er

C. ra

D. me



##### 27. 有正则表达式`/^\d{5,12}$/`,以下选项中能够匹配的是（）C

A、a100

B、8046976243181    // 13

C、80010

D、abcod



##### 28.在js中使用Date()对象中的哪个方法可以返回该日期对象对应的星期？（）D

A、getDate()

B、getFullYear()

C、getMonth()

D、getDay()



##### 29.页面有一个按钮button id为 button1，通过原生的js如何禁用   C

A: document.getElementById("button1").readolny= true;

B: document.getElementById("button1").setAttribute(“readolny”,”true”);

C: document.getElementById("button1").disabled = true;

D: document.getElementById("button1").getAttribute(“disabled”,”true”);



##### 30. 以下关于let和const的说法中正确的是 (多选   ：   )   A B C

A. **let**声明的变量值和类型都可以改变 

B. **const**声明的常量不可以改变

C. 两者都不存在变量提升，同时存在暂时性死区，只能在声明的位置后面使用 

D. **const**可以先声明再初始化，可以后赋值

---



## 二、 简答题  （共11题，总分50分）

##### 1. 说一说 标准盒模型  IE盒模型 区别 ？   (4 分)

##### 标准盒模型(W3C)



##### IE盒模型



##### 2. flex属性中的 0, 1, auto分别代表什么意思？（4分）

```css
flex: 0 1 auto;
```

```js
// 解答：
flex-grow, flex-shrink; flex-basis;
// 放大比例，缩小比例，项目在主轴上的初始大小
```



##### 3. 说一说事件委托的原理 ？（4分）

```js
// 
```





##### 4. 下面的代码打印什么内容 （4分）

```js
var a = 10
;(function(){
  console.log(a)   
  var a = 5
  console.log(window.a)  
  console.log(this.a)    
  a = 20
  console.log(a)        
})()
// undefine  10 10 20 
```



##### 5. 下列程序的输出结果是什么？（4分）

```js
var x = 1

var obj = {
  x: 3,
  fun: function(){
    var x = 5
    return this.x
  }
}
var fun = obj.fun
console.log(obj.fun(), fun()) 
// 3  1  
```



##### 6.  e.target 和 e.currentTarget 的区别 ？（4分）

```js
e.target 触发事件的元素
e.currentTarget  绑定事件的元素 
```





##### 7. sessionStorage 和 localStorage的区别？（4分）

```js
生命周期：sessionStorage关闭页面数据不存在，localStorage一直存在，除非手动删除
数据共享：sessionStorage当前页面， localStorage多窗口数据共享

```





##### 8. 获取页面被卷去的头部有哪两种方式？ （4分)

```js
document.documentElement.scrollTop
window.pageYOffset    
```



##### 9. 水平垂直居中的方式？（6分）

```js
1. flex 
2. absolute + 负margin
3. absolute + transform
4. absolute + left/right/top/bottom 0 + margin:auto;
5. absolute + cacl()
6. grid 
// 答
```





##### 10. 讲一讲JS的执行机制呢？（6分）

```js
```







##### 11  基本数据类型有哪些？检测数据类型(基本类型，引用类型)的方式？（6分）

```js
// 解答：
基本数据类型  7种 
(Number String Boolean  undefined null  Symbol  BigInt)  // 2 
Symbol  BigInt  ==>  
 
基本数据类型 typeof   // 1 
引用类型 A instanceof B  // 1 
perfect   ==> Object.prototype.toString.call()  // 2 
```



---



## 三、 代码题 （共40分）

##### 1. 动态创建一个div， 满足以下条件。   （6分）

1. 用Javascript动态创建一个div元素，将id设置为“mydiv”。  
2. 并设置一个值为 “hello JS” 的自定义属性 data-self。        
3. 该div字体颜色为orange，字号18，内容为”Javascript DIV”。并将该元素追加到body中来显示。

```js
// 注意代码题可以先在vscode中运行，之后往这里粘贴js代码
const div = document.createElement('div')
div.setAttribute('id', 'mydiv')
div.setAttribute('data-self', 'hello JS') 
div.style.color = 'orange'
div.style.fontSize = '18px'
div.innerHTML = 'Javascript DIV'
document.body.appendChild(div)

// 一波带走
document.body.innerHTML = '<div id="mydiv" data-self="hello JS" style="color:orange"></div>'
```



##### 2. 实现表格的全选和反选功能   （6分）

需求：

1. 点击上面全选复选框，下面所有的复选框都选中（全选）
2. 再次点击全选复选框，下面所有的复选框都不中选（取消全选）
3. 如果下面复选框全部选中，上面全选按钮就自动选中
4. 如果下面复选框有一个没有选中，上面全选按钮就不选中

![image-20220425021615319](imgs/image-20220425021615319.png)



```js
// 此处粘贴代码
```



##### 3. 实现tab栏切换功能  6分

![image-20220914134424182](imgs/image-20220914134424182.png)



```js
// 此处粘贴代码
```





##### 4. 请实现下面功能      6分

![2022-04-25_03-11-25](imgs/2022-04-25_03-11-25.gif)

```js
// 此处粘贴代码
```



##### 5. 根据提供的数据，动态创建表格，并实现表格上下移动和删除的功能  （16分）

![2022-04-25](imgs/2022-04-25.gif)

需求：

1. 动态创建表格

2. 表格行可上下移动，顶部上移第一条提示 --   已经到顶啦（不可再往上移动）

3. 表格底部下移最后一条提示 -- 已经到底啦 

4. 支持删除功能

   

可参考：

- 事件委托  `e.target`,    `innerHTML`
- document.createElement
- node.appendChild
- node.insertBefore
- node.parentNode
- node.children
- node.lastElementChild
- node.nextElementSibling
- node.previousElementSibling
- node.removeChild

**提示， 上下移动每一个tr， 可以用insertBefore() 实现 ， 当我们第一个参数是本身已存在的元素时， 可以做移动。**



```js
// 此处粘贴代码

// 渲染表格 8分
// 上下移动各 3分 
// 删除  2分 
```













