
for(let i = 0; i < 100; i++){
    console.log('吃饭睡觉打豆豆')
}

console.log('wahhh')