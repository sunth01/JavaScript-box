// 一次性导入所有内容
import * as module from './module/02.按需导出.js'

console.log('module', module)