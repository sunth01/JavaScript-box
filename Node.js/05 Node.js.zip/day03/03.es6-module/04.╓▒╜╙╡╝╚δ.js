import './module/03.有逻辑但没有导出的js.js'
// 直接导入，会运行导入模块里面的代码
// 不能有名字

// import {food} from './module/03.有逻辑但没有导出的js.js' 
// console.log('food', food)

