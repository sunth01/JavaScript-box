// 导入 dayjs
import dayjs from 'dayjs'
// 导入less
import './assets/less/index.less'

// 获取dom元素
const box = document.querySelector('.box')

console.log(goodbye)


setInterval(() => {
  box.innerHTML = dayjs().format('YYYY-MM🈷️DD HH:mm:ss---9999')
}, 1000)
// 默认设置一次
box.innerHTML = dayjs().format('YYYY-MM🈷️DD HH:mm:ss')
