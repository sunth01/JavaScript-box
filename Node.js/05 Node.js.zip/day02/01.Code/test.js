// 导入模块
const myModule = require('./myModule/myModule')
// console.log('msg:' msg)

console.log(myModule)

console.log(myModule.msg)
myModule.jump()