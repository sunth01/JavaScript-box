const msg = "感觉自己棒棒哒"
function jump(){  // (jump有一个很经典的话)
  console.log('you jump I jump')
}